# Heartwise / Cardio Signal: A Reproducible, Interpretable Decision-Tree Pipeline for Heart-Disease Risk Screening and Web Deployment

**Subtitle:** A technical and empirical case study of the `TitanicPredictionWeb` project

**Author:** Ayush Maurya

**Date:** 2 November 2026

**Repository:** <https://github.com/Ayushmauryap/heart_prediction>

**Document type:** Research paper / technical report

**Keywords:** heart disease; decision trees; interpretable machine learning; model calibration; ASP.NET Core; Razor Pages; MySQL; UCI Heart Disease dataset; model deployment; reproducibility

---

## Abstract

**Background.** Cardiovascular disease is the leading cause of death worldwide, and simple risk models can support—but never replace—clinical assessment. Many student and research projects stop at a notebook; fewer demonstrate a reproducible path from data cleaning and model selection to a deployed, auditable web application. **Objective.** This paper documents and evaluates Heartwise, publicly branded as Cardio Signal, an end-to-end educational system that estimates the presence of heart disease from ten routine clinical inputs using a shallow decision tree and persists screening results in MySQL. **Methods.** The 918-row combined UCI heart disease dataset was preprocessed with sex-specific median imputation for physiologically impossible zero values, fixed-order ordinal encoding, and MinMax scaling fitted inside each cross-validation fold. A grid of 70 tree configurations and six Beta-prior smoothing strengths was evaluated with stratified five-fold cross-validation. The model with the lowest mean log loss was exported to a compact JSON representation and embedded in an ASP.NET Core 8 Razor Pages application. **Results.** The selected model was an entropy-based tree of depth 4 with 21 nodes and 11 leaves, a minimum leaf size of 40, and Beta(3, 3) leaf smoothing. Cross-validated accuracy was 0.822 (95% bootstrap interval 0.797–0.846), ROC AUC 0.893 (0.871–0.914), log loss 0.399, and Brier score 0.124. At a 0.5 threshold, sensitivity was 86.4% and specificity 77.1%. The exported tree uses eight of the ten inputs and never splits on cholesterol; an exploratory nine-feature model without cholesterol achieved a slightly better cross-validated log loss of 0.396. The deployed model improved on the legacy fully grown pipeline (cross-validated accuracy 0.800, AUC 0.799, Brier 0.201) while producing eleven graded risk levels instead of two. **Conclusions.** A shallow, smoothed decision tree can provide a transparent and reasonably calibrated screening demonstration without a Python runtime. The project is an educational prototype, not a validated medical device. External validation, prospective evaluation, fairness analysis, clearer non-diagnostic wording, automated testing, and governance controls are required before any clinical use.

---

## 1. Introduction

### 1.1 Motivation

Cardiovascular diseases (CVDs) account for an estimated 17.9 million deaths each year, making them the leading cause of mortality globally [1]. Early identification of people at elevated risk can support lifestyle counselling, further investigation, and timely treatment. Statistical and machine-learning risk models have therefore been studied for decades, from the Framingham risk equations to modern gradient-boosted and deep-learning models. Yet the gap between a model that performs well in a notebook and a model that can be responsibly used, inspected, and maintained in a real setting remains large.

Three problems recur in applied student and research projects:

1. **Reproducibility.** Data cleaning, imputation, encoding, scaling, and model selection are often scattered across notebook cells, with inconsistent category orders and undocumented assumptions.
2. **Deployment.** A serialized Python pipeline is difficult to serve from a conventional web stack, and pickle files are sensitive to library-version drift.
3. **Communication.** A probability produced by a tree leaf is not necessarily a calibrated personal risk, and a binary label such as "heart disease" can be misread as a diagnosis.

This paper studies a project that attempts to address all three concerns in a small, self-contained system.

### 1.2 The Project

The project is stored in the repository `heart_prediction`; the web application lives in the folder `TitanicPredictionWeb` and is an ASP.NET Core 8 Razor Pages application. A user enters ten routine clinical measurements: age, sex, chest-pain type, resting blood pressure, cholesterol, fasting blood sugar, resting electrocardiogram (ECG) result, maximum heart rate, exercise-induced angina, and ST-slope category. The application encodes and scales these values, traverses an embedded decision tree, displays a risk score and a flag, and writes the input and result to a MySQL table.

The repository also contains the original exploratory notebook (`predict_heart_disease.ipynb`), a small inference notebook (`predict_heartpart2.ipynb`), the legacy serialized scikit-learn pipeline (`pipe.pkl`), the combined dataset (`heart.csv`), and a retraining/export script (`train_heart_model.py`). The deployed model is not loaded from `pipe.pkl`; it is a shallow, smoothed tree retrained by `train_heart_model.py` and exported to `TitanicPredictionWeb/Models/heart-disease-model.json`, a 1,785-byte file embedded into the .NET assembly.

The project uses several names: the folder is `TitanicPredictionWeb`, the assembly and namespace are `HeartHealthWeb`, the web brand is `Cardio Signal`, the README calls the product `Heartwise`, and the database is `titanic_db`. This naming debt is documented in Section 6.10 as a maintainability issue rather than hidden.

### 1.3 Objectives

The project and this paper pursue the following objectives:

1. Build a complete, reproducible pipeline from a public CSV dataset to a running web application.
2. Use a model simple enough to be inspected and explained to a non-specialist.
3. Avoid the binary 0%/100% outputs of a fully grown tree by limiting depth and smoothing leaf probabilities.
4. Keep the production runtime independent of Python and scikit-learn.
5. Persist screening inputs and outputs in a relational database without destroying pre-existing data.
6. Evaluate the deployed model honestly, including its limitations and its comparison with the legacy pipeline.
7. Identify the engineering, ethical, and regulatory work that would be required before clinical use.

### 1.4 Contributions

The main contributions of the work are:

- **An end-to-end reference implementation** that connects data preparation, model selection, JSON export, ASP.NET Core inference, and MySQL persistence in one repository.
- **A leakage-aware preprocessing protocol** in which imputation, encoding, and scaling are fitted inside each cross-validation fold.
- **A systematic model-selection procedure** covering 70 tree configurations and six smoothing strengths, selected by log loss rather than accuracy alone.
- **A compact, language-agnostic model contract** that represents a fitted scikit-learn tree as arrays and scalars, allowing exact inference in C# without a Python runtime.
- **A critical empirical comparison** between the deployed shallow tree and the legacy fully grown pipeline, including cross-validation, hold-out behaviour, calibration, and ablations for omitted or unused features.
- **A candid account of limitations**, including dataset bias, missing-value handling, non-calibrated leaf scores, diagnostic wording in the user interface, and the absence of automated tests and external validation.

### 1.5 Scope and Non-Goals

This is an educational and engineering case study. It is **not** a clinical trial, a medical device, a diagnostic system, or a substitute for professional medical advice. The model is trained on a public, retrospective, de-identified dataset. No new patient data were collected. The system has not been externally validated, prospectively evaluated, or reviewed by a regulatory body. The paper therefore treats predictive performance as an internal, descriptive result rather than a claim of clinical utility.

---

## 2. Background

### 2.1 Clinical and Epidemiological Context

Coronary artery disease and other cardiovascular conditions are multifactorial. Well-established risk factors include older age, male sex, elevated blood pressure, dyslipidaemia, diabetes or impaired fasting glucose, smoking, obesity, physical inactivity, and a family history of premature CVD [1, 2]. Clinical presentations vary from asymptomatic disease to stable angina, unstable angina, and myocardial infarction. Chest-pain type, resting ECG findings, exercise-induced angina, maximum heart rate, and ST-segment slope are commonly used in non-invasive assessment and exercise testing.

The dataset used here encodes several of these factors. It does not include smoking, diabetes (only fasting blood sugar), body mass index, family history, or medication use. A model trained on such a limited feature set can only capture a partial picture. This is one reason the application is framed as an educational demonstration rather than a screening programme.

### 2.2 The UCI Heart Disease Data

The original UCI Heart Disease dataset was assembled by Detrano and colleagues and donated in 1988 [3, 4]. It combines data from four institutions: the Cleveland Clinic Foundation, the Hungarian Institute of Cardiology in Budapest, the University Hospital in Zürich, and the V.A. Medical Center in Long Beach, California. The UCI version contains 920 records and 76 attributes, although most studies use a 14-attribute subset. The target is usually a binary indicator of angiographic coronary artery disease, derived from a stenosis severity threshold.

The `heart.csv` file in this project has 918 rows and 12 columns: eleven predictors and one binary target. This is the widely circulated "Heart Failure Prediction Dataset" derivative distributed on Kaggle [5]. It is derived from the same combined UCI sources but is not identical to the raw UCI distribution: it may exclude a small number of records, it recodes the field names, and it presents the target as `HeartDisease` with values 0 and 1. The project's README and model metadata describe it as the "combined UCI heart disease dataset (918 records)". That description is accurate at the level of provenance, but users should consult the original UCI documentation and the Kaggle dataset page for exact licensing and preprocessing details before redistributing the data.

### 2.3 Decision Trees for Clinical Prediction

A decision tree recursively partitions a feature space into rectangular regions. At each internal node, a feature and threshold are chosen to maximise a purity criterion; at each leaf, a prediction is stored. For classification, common criteria are Gini impurity and entropy. The resulting model is attractive in clinical and educational settings because it can be displayed as a set of if-then rules, audited by a clinician, and explained without post-hoc approximation [6, 7, 20].

Trees also have well-known weaknesses. A fully grown tree can memorise training data, produce extremely confident leaves, and change substantially under small perturbations. Single trees are high-variance estimators. These problems are usually addressed by pruning, depth limits, minimum leaf sizes, ensembling (random forests, gradient boosting), or smoothing. This project deliberately chooses a shallow single tree to preserve interpretability, and compensates for the loss of flexibility with depth and leaf-size constraints plus Beta-prior smoothing.

### 2.4 Probability, Calibration, and Decision Thresholds

A classifier's output can be a class label or a score. A score is not automatically a probability. Calibration refers to agreement between predicted probabilities and observed event rates: among patients assigned a score of 0.8, approximately 80% should experience the event if the score is well calibrated [8, 9]. Calibration is important because clinical decisions depend on absolute risk, not only on ranking.

Common metrics reflect different aspects of performance:

- **Discrimination** (ROC AUC) measures the probability that a randomly chosen positive case receives a higher score than a randomly chosen negative case.
- **Log loss** penalises confident wrong predictions and is sensitive to probability quality.
- **Brier score** is the mean squared error of probabilistic predictions.
- **Accuracy, sensitivity, specificity, positive predictive value (PPV), and negative predictive value (NPV)** describe behaviour at a chosen threshold.

A model can rank well but be poorly calibrated, or be accurate at one threshold but clinically unhelpful at another. The application uses a fixed 0.5 threshold for the displayed flag, but the underlying score is continuous. The project explicitly warns that the displayed score is a leaf class share, not a personal clinical probability. This distinction is central to the paper's discussion.

### 2.5 Deployment and Reproducibility

Deploying a model is an engineering activity, not only a modelling one. A production system needs a stable inference contract, deterministic preprocessing, dependency management, input validation, error handling, persistence, and a way to audit what was predicted. Serialized Python objects are convenient for experimentation but fragile across library versions. The project's answer is to export the fitted tree's structure and preprocessing parameters to JSON, embed that JSON in a .NET assembly, and implement the traversal in C#. This removes the Python runtime from the serving path and makes the model contract explicit.

The broader reproducibility literature emphasises complete reporting of data sources, preprocessing, model selection, performance, and limitations [10, 11]. This paper follows that spirit: it reports not only the selected model and its metrics but also the alternatives that were considered, the features that were omitted, the legacy pipeline that was replaced, and the engineering controls that are still missing.

---

## 3. System Overview

### 3.1 Architecture

The application is a conventional server-rendered web app with a single prediction endpoint implemented as a Razor Page. The flow is:

```text
┌─────────────────────────────────────────────────────────────────────┐
│ Browser                                                             │
│  • 10-field screening form                                          │
│  • client-side constraints (number, min, max, select)               │
│  • POST to /Index                                                   │
└───────────────────────────────┬─────────────────────────────────────┘
                                │ HTTPS form POST
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│ ASP.NET Core 8 Razor Pages                                          │
│  Pages/Index.cshtml.cs                                              │
│  • model binding → HeartDiseaseInput                                │
│  • DataAnnotations validation                                       │
│  • OnPostAsync()                                                    │
└───────────────────────────────┬─────────────────────────────────────┘
                                │ HeartDiseaseInput
                                ▼
┌─────────────────────────────────────────────────────────────────────┐
│ HeartDiseasePredictionService (singleton)                           │
│  • loads embedded heart-disease-model.json once                     │
│  • validates array lengths and 10-feature contract                  │
│  • ordinal-encodes categorical values                               │
│  • applies MinMax scale and offset                                  │
│  • traverses the tree (at most 4 comparisons)                       │
│  • returns HeartDiseasePredictionResult(flag, score)                │
└───────────────┬─────────────────────────────────┬───────────────────┘
                │ result                          │ input + result
                ▼                                 ▼
┌───────────────────────────────┐   ┌─────────────────────────────────┐
│ Razor result card             │   │ HeartDiseaseRepository (scoped) │
│  • flag / clear state         │   │  • parameterised INSERT         │
│  • score meter                │   │  • MySQL 8.4                    │
│  • database status message    │   │  • heart_disease_predictions    │
└───────────────────────────────┘   └─────────────────────────────────┘
```

The model is computed before persistence. If MySQL is unavailable, the user still sees the model result and a clear message that the record could not be saved. This separation is a deliberate resilience choice.

### 3.2 Technology Stack

| Layer | Technology | Version / notes |
|---|---|---|
| Runtime | .NET | 8.0 |
| Web framework | ASP.NET Core Razor Pages [17] | `Microsoft.NET.Sdk.Web` |
| Language | C# | Nullable and implicit usings enabled |
| Data access | MySqlConnector | 2.6.2 |
| Database | MySQL | 8.4.13 portable local installation in the development environment |
| Model training | Python | 3.13 virtual environment |
| Modelling library | scikit-learn [16] | 1.9.1 in the current `.venv`; legacy `pipe.pkl` reports 1.6.1 |
| Data handling | pandas / NumPy | 3.1.0 / 2.5.4 |
| Model artifact | JSON | 1,785 bytes, embedded resource |
| IDE integration | VS Code tasks | Start website; initialise database |
| Host OS | Windows | Paths and PowerShell script are Windows-specific |

The production application does **not** need Python, pandas, NumPy, or scikit-learn. The Python environment is used only to retrain and export the model.

### 3.3 Request Lifecycle

1. A `GET /` request renders `Pages/Index.cshtml` with an empty `HeartDiseaseInput` populated by default values.
2. The user submits the form with `POST /`.
3. Razor Pages binds form values to `IndexModel.Patient` and runs DataAnnotations validation.
4. If validation fails, the page is re-rendered with field-level and summary errors; no prediction is made.
5. If validation succeeds, `HeartDiseasePredictionService.Predict` encodes, scales, and traverses the tree.
6. The page model attempts to persist the input and result through `HeartDiseaseRepository.SaveAsync`.
7. A successful insert sets `SavedToDatabase = true`; a MySQL or configuration error is logged and surfaced as a user-readable message.
8. The page is re-rendered with the result card, score meter, flag, and database status.

### 3.4 Repository Layout

| Path | Purpose |
|---|---|
| `heart.csv` | 918-row combined UCI heart disease dataset |
| `predict_heart_disease.ipynb` | Original exploratory notebook and legacy pipeline construction |
| `predict_heartpart2.ipynb` | Small notebook that loads `pipe.pkl` and predicts one profile |
| `pipe.pkl` | Legacy serialized scikit-learn pipeline (245 nodes, 123 leaves) |
| `train_heart_model.py` | Retraining, model selection, JSON export, and round-trip verification |
| `TitanicPredictionWeb/TitanicPredictionWeb.csproj` | Web project; assembly name `HeartHealthWeb` |
| `TitanicPredictionWeb/Program.cs` | Application bootstrap and dependency injection |
| `TitanicPredictionWeb/Models/HeartDiseaseInput.cs` | Input DTO with validation attributes |
| `TitanicPredictionWeb/Models/HeartDiseasePredictionResult.cs` | Output record `(HasHeartDisease, ModelScore)` |
| `TitanicPredictionWeb/Models/heart-disease-model.json` | Embedded tree and preprocessing parameters |
| `TitanicPredictionWeb/Services/HeartDiseasePredictionService.cs` | Runtime inference engine |
| `TitanicPredictionWeb/Services/HeartDiseaseRepository.cs` | Parameterised MySQL insert |
| `TitanicPredictionWeb/Pages/Index.cshtml` | Screening form and result UI |
| `TitanicPredictionWeb/Pages/Index.cshtml.cs` | Page handler and orchestration |
| `TitanicPredictionWeb/Pages/Error.cshtml` | User-friendly error page |
| `TitanicPredictionWeb/wwwroot/css/site.css` | Dark, responsive visual design |
| `TitanicPredictionWeb/database/init.sql` | Database and table creation |
| `TitanicPredictionWeb/Start-HeartHealth.ps1` | Starts MySQL if needed, prompts for password, runs the app |
| `.vscode/tasks.json` | VS Code tasks for starting the app and initialising the database |

---

## 4. Dataset

### 4.1 Provenance and Licensing

The dataset is a public, retrospective, de-identified collection derived from the UCI Heart Disease database [3, 4, 5]. It contains patients from four clinical centres and is widely used in teaching and benchmarking. Because the Kaggle derivative may differ from the raw UCI distribution in record selection and recoding, the exact provenance of every row cannot be reconstructed from the repository alone. The repository does not include a license file for `heart.csv`; anyone redistributing the data should verify the UCI and Kaggle terms.

### 4.2 Schema

| Column | Type in CSV | Observed range / categories | Role |
|---|---|---|---|
| `Age` | integer | 28–77 years | Predictor |
| `Sex` | string | `M`, `F` | Predictor |
| `ChestPainType` | string | `ASY`, `NAP`, `ATA`, `TA` | Predictor |
| `RestingBP` | integer | 0–200 mm Hg (one zero) | Predictor |
| `Cholesterol` | integer | 0–603 mg/dL (172 zeros) | Predictor |
| `FastingBS` | integer | 0, 1 | Predictor |
| `RestingECG` | string | `Normal`, `ST`, `LVH` | Predictor |
| `MaxHR` | integer | 60–202 bpm | Predictor |
| `ExerciseAngina` | string | `Y`, `N` | Predictor |
| `Oldpeak` | float | −2.6–6.2 | Present in data, **not used** by deployed model |
| `ST_Slope` | string | `Flat`, `Up`, `Down` | Predictor |
| `HeartDisease` | integer | 0, 1 | Target |

`Oldpeak` is ST-segment depression induced by exercise relative to rest. It is a clinically meaningful variable, but the web form does not collect it, so the deployed model is trained without it. Section 7.6 reports an ablation that adds it back under the same protocol.

### 4.3 Descriptive Statistics

| Variable | Mean | Std. dev. | Min | 25th pct. | Median | 75th pct. | Max |
|---|---:|---:|---:|---:|---:|---:|---:|
| Age | 53.51 | 9.43 | 28 | 47 | 54 | 60 | 77 |
| RestingBP | 132.40 | 18.51 | 0 | 120 | 130 | 140 | 200 |
| Cholesterol | 198.80 | 109.38 | 0 | 173.25 | 223 | 267 | 603 |
| FastingBS | 0.233 | 0.423 | 0 | 0 | 0 | 0 | 1 |
| MaxHR | 136.81 | 25.46 | 60 | 120 | 138 | 156 | 202 |
| Oldpeak | 0.887 | 1.067 | −2.6 | 0.0 | 0.6 | 1.5 | 6.2 |
| HeartDisease | 0.553 | 0.497 | 0 | 0 | 1 | 1 | 1 |

The cholesterol distribution is visibly distorted by the 172 zero values: the mean of 198.8 mg/dL and standard deviation of 109.4 are not plausible for a clinical population without treatment. After treating zeros as missing and imputing within sex, the effective distribution is narrower. The resting blood pressure distribution is similarly affected by one zero.

### 4.4 Class and Category Distribution

| Variable | Category | Count | Share |
|---|---|---:|---:|
| Target | No heart disease (0) | 410 | 44.7% |
| Target | Heart disease (1) | 508 | 55.3% |
| Sex | Male | 725 | 79.0% |
| Sex | Female | 193 | 21.0% |
| ChestPainType | Asymptomatic (`ASY`) | 496 | 54.0% |
| ChestPainType | Non-anginal pain (`NAP`) | 203 | 22.1% |
| ChestPainType | Atypical angina (`ATA`) | 173 | 18.8% |
| ChestPainType | Typical angina (`TA`) | 46 | 5.0% |
| RestingECG | Normal | 552 | 60.1% |
| RestingECG | Left ventricular hypertrophy (`LVH`) | 188 | 20.5% |
| RestingECG | ST-T wave abnormality (`ST`) | 178 | 19.4% |
| ExerciseAngina | No | 547 | 59.6% |
| ExerciseAngina | Yes | 371 | 40.4% |
| ST_Slope | Flat | 460 | 50.1% |
| ST_Slope | Up | 395 | 43.0% |
| ST_Slope | Down | 63 | 6.9% |

The dataset is moderately imbalanced (55/45), not severely so. The sex distribution is heavily skewed toward male patients (79%), which limits any claim about fairness or performance in women. The chest-pain distribution is dominated by asymptomatic presentations (54%), a pattern that reflects the referral population and affects the interpretation of chest-pain categories.

### 4.5 Data Quality and Preprocessing Decisions

The following issues were identified and handled:

1. **Cholesterol zeros.** 172 records (18.7%) have `Cholesterol = 0`. A total cholesterol of zero is physiologically impossible in a living adult and is conventionally treated as missing. These values were replaced with `NaN` before imputation.
2. **Resting blood pressure zeros.** One record has `RestingBP = 0`, also physiologically impossible. It was treated as missing.
3. **Oldpeak anomalies.** The minimum Oldpeak is −2.6. ST depression is normally non-negative; negative values may be coding artefacts or measurement conventions. Because the web form does not collect Oldpeak, the variable was dropped from the deployed model. This also avoids propagating its anomalies.
4. **No explicit missing values.** The CSV has no `NaN` cells; missingness is encoded as zero for the two variables above.
5. **Categorical consistency.** All categorical values match the expected sets. The training script raises an error if an unknown category appears, which prevents silent encoding failures.
6. **Class balance.** The 55/45 split is workable without resampling. The training script uses stratified folds to preserve the ratio.
7. **Site heterogeneity.** The four source centres may differ in measurement practices and disease prevalence. The model does not include a site indicator, so it learns a pooled pattern.

### 4.6 Privacy and Ethical Use

The dataset is public and de-identified. Nevertheless, the combination of age, sex, and clinical measurements can constitute quasi-identifying information in small subgroups. The web application does not collect names, addresses, identifiers, or free-text notes. It does store the ten inputs and the model output, with a timestamp, in MySQL. In a real deployment, this would require a lawful basis, informed consent or an appropriate waiver, data-minimisation review, retention limits, access controls, and a privacy impact assessment. The current local demo has none of these controls and should not be exposed to the public internet with real patient data.

---

## 5. Methodology

### 5.1 Problem Formulation

Let \(x_i \in \mathbb{R}^{10}\) be the encoded and scaled feature vector for patient \(i\), and let \(y_i \in \{0,1\}\) be the binary target. The model estimates a score

\[
s_i = f(x_i) \in [0,1],
\]

where \(f\) is a decision tree whose leaves store smoothed positive-class rates. The displayed flag is

\[
\hat{y}_i = \begin{cases}
1 & \text{if } s_i > 0.5,\\
0 & \text{otherwise}.
\end{cases}
\]

The score is a model output, not a calibrated probability of disease for an individual patient. This distinction is repeated in the application's disclaimers and in Section 8.4.

### 5.2 Preprocessing Pipeline

The preprocessing pipeline is implemented in `train_heart_model.py` and mirrored exactly in `HeartDiseasePredictionService.cs`. The order is important because the JSON export assumes a fixed transformed-vector layout.

1. **Drop `Oldpeak`.** The deployed model uses ten inputs; `Oldpeak` is removed before any fitting.
2. **Zero-to-missing conversion.** For `Cholesterol` and `RestingBP`, values less than or equal to zero are replaced with `NaN`.
3. **Sex-specific median imputation.** Within each training fold, the median of each imputed variable is computed separately for male and female patients. A missing value is replaced by the median for that patient's sex. If a sex-specific median is unavailable, the global median is used as a fallback.
4. **Ordinal encoding.** Categorical variables are mapped to integers using a fixed category order. The order is part of the model contract and must not change between training and serving.
5. **MinMax scaling.** Each of the ten transformed features is scaled to the [0, 1] range using statistics fitted on the training fold.
6. **No feature selection.** All ten transformed features are retained. The legacy pipeline used `SelectKBest(chi2, k=10)`, which also kept all ten features.

The imputation, encoding, and scaling steps are fitted **inside each cross-validation fold**. This prevents validation-fold information from leaking into the training process. The final model is then refitted on all 918 rows using medians and scaler statistics computed from the full dataset.

### 5.3 Ordinal Encoding

The category orders are fixed by the C# service and the training script:

| Feature | Category order | Encoded values |
|---|---|---|
| `ChestPainType` | `ASY`, `NAP`, `ATA`, `TA` | 0, 1, 2, 3 |
| `RestingECG` | `Normal`, `ST`, `LVH` | 0, 1, 2 |
| `ExerciseAngina` | `Y`, `N` | 0, 1 |
| `ST_Slope` | `Flat`, `Up`, `Down` | 0, 1, 2 |
| `Sex` | `M`, `F` | 0, 1 |

The transformed-vector order is:

```text
ChestPainType, RestingECG, ExerciseAngina, ST_Slope, Sex,
Age, RestingBP, Cholesterol, FastingBS, MaxHR
```

This order differs from the raw CSV column order. The discrepancy is intentional: it matches the order produced by the legacy `ColumnTransformer` and is the order expected by the exported tree's `splitFeatures` indices. Any change to this order would silently corrupt inference, which is why the service validates array lengths and the training script documents the contract.

### 5.4 MinMax Scaling

The scaler applies

\[
x'_{i,j} = x_{i,j} \cdot a_j + b_j,
\]

where \(a_j\) is `scalerScales[j]` and \(b_j\) is `scalerOffsets[j]`. The parameters in the exported model imply the following training ranges:

| Feature | Scale \(a_j\) | Offset \(b_j\) | Implied minimum | Implied maximum |
|---|---:|---:|---:|---:|
| `ChestPainType` | 0.3333333333 | 0.0000000000 | 0 | 3 |
| `RestingECG` | 0.5000000000 | 0.0000000000 | 0 | 2 |
| `ExerciseAngina` | 1.0000000000 | 0.0000000000 | 0 | 1 |
| `ST_Slope` | 0.5000000000 | 0.0000000000 | 0 | 2 |
| `Sex` | 1.0000000000 | 0.0000000000 | 0 | 1 |
| `Age` | 0.0204081633 | −0.5714285714 | 28 | 77 |
| `RestingBP` | 0.0083333333 | −0.6666666667 | 80 | 200 |
| `Cholesterol` | 0.0019305019 | −0.1640926641 | 85 | 603 |
| `FastingBS` | 1.0000000000 | 0.0000000000 | 0 | 1 |
| `MaxHR` | 0.0070422535 | −0.4225352113 | 60 | 202 |

The implied ranges are the min and max of the imputed training data, not the raw CSV minima. For example, the raw `RestingBP` minimum is 0, but after treating zero as missing and imputing, the minimum used by the scaler is 80. The raw `Cholesterol` minimum is 0, but the imputed minimum is 85. These ranges matter for understanding the tree thresholds: a threshold expressed in scaled units can be converted back to raw units with \(x = (x' - b_j)/a_j\).

### 5.5 Model Family and Objective

The model is a CART-style decision tree classifier [6]. At each candidate split, the algorithm selects the feature and threshold that maximise the reduction in impurity. For entropy, the impurity of a node \(t\) is

\[
H(t) = -\sum_{k \in \{0,1\}} p_{t,k} \log_2 p_{t,k},
\]

where \(p_{t,k}\) is the proportion of class \(k\) in node \(t\). The information gain of a split is the parent impurity minus the weighted sum of child impurities. The tree is constrained by `max_depth` and `min_samples_leaf` to prevent full memorisation.

Gini impurity was also evaluated:

\[
G(t) = 1 - \sum_{k \in \{0,1\}} p_{t,k}^2.
\]

The selected model uses entropy. Gini and entropy often produce similar trees, but entropy can favour slightly more balanced splits and was the better choice under the log-loss criterion for this dataset.

### 5.6 Hyperparameter Search

The search grid was:

| Hyperparameter | Values | Count |
|---|---|---:|
| `max_depth` | 3, 4, 5, 6, 7 | 5 |
| `min_samples_leaf` | 20, 30, 40, 50, 60, 80, 100 | 7 |
| `criterion` | `gini`, `entropy` | 2 |
| Leaf smoothing \(\alpha\) | 0.5, 1, 2, 3, 5, 8 | 6 |

The number of tree configurations is \(5 \times 7 \times 2 = 70\). Each configuration was evaluated with six smoothing strengths, giving \(70 \times 6 = 420\) candidate (configuration, \(\alpha\)) pairs. Each candidate was trained and evaluated with stratified five-fold cross-validation (seed 42). The selection criterion was the lowest mean log loss across the pooled out-of-fold predictions; ROC AUC was used as a tie-breaker.

This is a modest but adequate search for a dataset of 918 rows. It is not a full Bayesian optimisation or nested cross-validation study. The same data are used for selection and performance reporting, so the reported metrics are optimistically biased to an unknown degree. Section 8.5 discusses this limitation.

### 5.7 Leaf Smoothing

A fully grown tree can produce leaves with empirical positive rates of exactly 0 or 1. Such outputs are overconfident and make log loss and Brier score unnecessarily poor. The project applies a Beta prior to each leaf:

\[
\hat{p}_{\ell} = \frac{n_{\ell}^{+} + \alpha}{n_{\ell} + 2\alpha},
\]

where \(n_{\ell}^{+}\) is the number of positive training examples in leaf \(\ell\), \(n_{\ell}\) is the total number of training examples in leaf \(\ell\), and \(\alpha > 0\) is the smoothing strength. This is the posterior mean of a Beta(\(\alpha\), \(\alpha\)) prior after observing \(n_{\ell}^{+}\) positives and \(n_{\ell}^{-}\) negatives. It shrinks small or extreme leaves toward 0.5. The selected value is \(\alpha = 3\).

With a minimum leaf size of 40, the shrinkage is modest: a leaf with 40 positives and 0 negatives receives \((40+3)/(40+6) = 0.935\), not 1.0. A leaf with 3 positives and 37 negatives receives \((3+3)/(40+6) = 0.130\), not 0.075. The smoothing therefore reduces extremes without erasing the signal.

### 5.8 Final Model Fitting and Export

After selecting the best configuration and \(\alpha\), the training script refits the tree on all 918 rows using the full-data imputation medians and scaler statistics. It then exports:

- the encoded category orders,
- the scaler scales and offsets,
- the transformed-feature order,
- the selected-feature mask,
- the tree's `children_left`, `children_right`, `feature`, and `threshold` arrays,
- the smoothed positive probability for each leaf,
- training metadata and cross-validation metrics.

Internal-node probabilities are set to zero in the export; only leaf probabilities are used at inference. The JSON is written to `TitanicPredictionWeb/Models/heart-disease-model.json` and embedded in the assembly under the logical name `HeartHealthWeb.Models.heart-disease-model.json`.

The export script includes a round-trip check: it re-implements the JSON traversal in Python and compares its output with scikit-learn's leaf assignments for every training row. In this run, **918/918 rows matched** at a tolerance of \(10^{-12}\). This check is important because it catches index-order and scaling mistakes before deployment.

### 5.9 Runtime Inference Contract

The C# service implements the following algorithm:

```csharp
var transformed = new[]
{
    Encode(input.ChestPainType, model.EncodedCategories.ChestPainType),
    Encode(input.RestingECG,     model.EncodedCategories.RestingECG),
    Encode(input.ExerciseAngina, model.EncodedCategories.ExerciseAngina),
    Encode(input.STSlope,        model.EncodedCategories.ST_Slope),
    Encode(input.Sex,            model.EncodedCategories.Sex),
    (double)input.Age,
    input.RestingBP,
    input.Cholesterol,
    input.FastingBS,
    input.MaxHR
};

var scaled = new List<double>();
for (var i = 0; i < transformed.Length; i++)
{
    if (model.SelectedFeatures[i])
        scaled.Add(transformed[i] * model.ScalerScales[i] + model.ScalerOffsets[i]);
}

var node = 0;
while (model.SplitFeatures[node] >= 0)
{
    var feature = model.SplitFeatures[node];
    node = scaled[feature] <= model.SplitThresholds[node]
        ? model.ChildrenLeft[node]
        : model.ChildrenRight[node];
}

var score = model.PositiveProbabilities[node];
return new HeartDiseasePredictionResult(score > 0.5, score);
```

The service validates that all tree arrays have the same length, that the scaler arrays match the selected-feature mask, and that the mask has exactly ten entries. If the embedded resource is missing or inconsistent, it throws an `InvalidDataException` when the service is constructed rather than serving silently wrong predictions.

### 5.10 Evaluation Protocol and Metrics

The primary evaluation is stratified five-fold cross-validation with out-of-fold predictions. For each fold, imputation, encoding, and scaling are fitted on the training portion and applied to the validation portion. The selected configuration and \(\alpha\) are used to generate a score for every row exactly once. The pooled out-of-fold scores are then used to compute:

\[
\text{Accuracy} = \frac{TP + TN}{TP + TN + FP + FN},
\]

\[
\text{Sensitivity} = \frac{TP}{TP + FN}, \qquad
\text{Specificity} = \frac{TN}{TN + FP},
\]

\[
\text{PPV} = \frac{TP}{TP + FP}, \qquad
\text{NPV} = \frac{TN}{TN + FN},
\]

\[
\text{Log loss} = -\frac{1}{N}\sum_{i=1}^{N}\left[y_i \log s_i + (1-y_i)\log(1-s_i)\right],
\]

\[
\text{Brier} = \frac{1}{N}\sum_{i=1}^{N}(s_i - y_i)^2.
\]

ROC AUC is computed from the continuous scores. Calibration is inspected by binning the out-of-fold scores into five equal-width bins and comparing the mean predicted score with the observed positive rate in each bin. A non-parametric bootstrap with 2,000 resamples of the out-of-fold predictions is used to provide a descriptive 95% interval; this interval reflects sampling variability of the evaluation rows, not uncertainty from model selection or training.

### 5.11 Reproducibility Controls

The following controls make the result reproducible:

- **Fixed seed.** `random_state = 42` for the cross-validation splitter and the tree.
- **Fixed category order.** The order is duplicated in Python and C# and documented in the JSON.
- **Deterministic tree.** scikit-learn's tree fitting is deterministic given the data, hyperparameters, and seed.
- **Round-trip verification.** 918/918 training rows match between the Python reference and the exported JSON.
- **Single artifact.** The deployed model is one 1,785-byte JSON file embedded in the assembly.
- **No runtime Python.** The serving path has no pickle, no scikit-learn, and no version-sensitive deserialization.

The main reproducibility gap is dependency pinning: the repository does not include a `requirements.txt` or lock file. The current `.venv` has pandas 3.1.0, NumPy 2.5.4, and scikit-learn 1.9.1, while `pipe.pkl` was created with scikit-learn 1.6.1. Retraining with a different scikit-learn version could produce slightly different trees or probabilities.

---

## 6. Implementation

### 6.1 Application Structure and Dependency Injection

`Program.cs` is intentionally small:

```csharp
using HeartHealthWeb.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddSingleton<HeartDiseasePredictionService>();
builder.Services.AddScoped<HeartDiseaseRepository>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.MapRazorPages();

app.Run();
```

The prediction service is a singleton because the model is immutable and loaded once from the embedded resource. The repository is scoped because it opens a database connection per request. This is a standard and appropriate lifetime choice.

### 6.2 Input Model and Validation

`HeartDiseaseInput` is a sealed class with DataAnnotations validation:

| Property | Validation | Default | UI label |
|---|---|---:|---|
| `Age` | `[Range(1, 120)]` | 45 | Age |
| `Sex` | `[RegularExpression("^(M\|F)$")]` | `M` | Sex |
| `ChestPainType` | `[RegularExpression("^(ASY\|NAP\|ATA\|TA)$")]` | `ATA` | Chest pain type |
| `RestingBP` | `[Range(0, 300)]` | 120 | Resting blood pressure (mm Hg) |
| `Cholesterol` | `[Range(0, 1000)]` | 200 | Cholesterol (mg/dL) |
| `FastingBS` | `[Range(0, 1)]` | 0 | Fasting blood sugar above 120 mg/dL |
| `RestingECG` | `[RegularExpression("^(Normal\|ST\|LVH)$")]` | `Normal` | Resting ECG |
| `MaxHR` | `[Range(0, 300)]` | 150 | Maximum heart rate (bpm) |
| `ExerciseAngina` | `[RegularExpression("^(Y\|N)$")]` | `N` | Exercise-induced angina |
| `STSlope` | `[RegularExpression("^(Flat\|Up\|Down)$")]` | `Up` | ST slope |

The ranges are deliberately wider than the training data to accommodate plausible clinical values. For example, the training `RestingBP` range after imputation is 80–200, but the form accepts 0–300. A value outside the training range is not rejected by the model; it is scaled and may produce an extreme score. This is a known limitation of tree models: they extrapolate as constants beyond the observed splits, but the scaling can place the value in a region that was never seen. A future version should warn when an input is outside the training range.

The regular expressions provide server-side protection against tampered form values. The UI also uses `<select>` elements for categorical fields, so most users cannot submit an invalid category through the normal interface.

### 6.3 Page Handler and User Flow

`IndexModel` uses primary-constructor dependency injection:

```csharp
public sealed class IndexModel(
    HeartDiseasePredictionService predictionService,
    HeartDiseaseRepository predictionRepository,
    ILogger<IndexModel> logger) : PageModel
{
    [BindProperty]
    public HeartDiseaseInput Patient { get; set; } = new();

    public HeartDiseasePredictionResult? Result { get; private set; }
    public bool SavedToDatabase { get; private set; }
    public string? DatabaseMessage { get; private set; }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
            return Page();

        Result = predictionService.Predict(Patient);

        try
        {
            await predictionRepository.SaveAsync(Patient, Result);
            SavedToDatabase = true;
        }
        catch (MySqlException exception)
        {
            logger.LogError(exception, "Could not save a heart disease prediction to MySQL.");
            DatabaseMessage = "The model result was calculated, but it could not be saved. ...";
        }
        catch (InvalidOperationException exception)
        {
            logger.LogError(exception, "MySQL connection configuration is missing or invalid.");
            DatabaseMessage = exception.Message;
        }

        return Page();
    }
}
```

The handler separates prediction from persistence. A database failure does not discard the model result. This is good for a demo and for user experience, but it also means that a production system could silently accumulate unsaved predictions. A real system should add a retry queue or a durable outbox.

### 6.4 Persistence Layer

`HeartDiseaseRepository` reads the connection string from configuration:

```csharp
var connectionString = configuration.GetConnectionString("HeartDiseaseDatabase");
if (string.IsNullOrWhiteSpace(connectionString))
    throw new InvalidOperationException(
        "Set the ConnectionStrings__HeartDiseaseDatabase environment variable before saving predictions.");
```

It then opens a `MySqlConnection` [18] and executes a parameterised `INSERT`:

```sql
INSERT INTO heart_disease_predictions
    (age, sex, chest_pain_type, resting_bp, cholesterol, fasting_bs, resting_ecg,
     max_hr, exercise_angina, st_slope, predicted_heart_disease, model_score)
VALUES
    (@age, @sex, @chestPainType, @restingBP, @cholesterol, @fastingBS, @restingECG,
     @maxHR, @exerciseAngina, @stSlope, @predictedHeartDisease, @modelScore);
```

All values are passed as `MySqlParameter` objects. This prevents SQL injection and handles type conversion correctly. The repository does not read or update existing records, and it does not expose a query API.

### 6.5 Database Schema

`database/init.sql` creates the database if it does not exist and creates the predictions table if it does not exist, using the MySQL 8.4 dialect [19]:

```sql
CREATE DATABASE IF NOT EXISTS titanic_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE titanic_db;

CREATE TABLE IF NOT EXISTS heart_disease_predictions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    age SMALLINT UNSIGNED NOT NULL,
    sex CHAR(1) NOT NULL,
    chest_pain_type VARCHAR(3) NOT NULL,
    resting_bp SMALLINT UNSIGNED NOT NULL,
    cholesterol SMALLINT UNSIGNED NOT NULL,
    fasting_bs TINYINT UNSIGNED NOT NULL,
    resting_ecg VARCHAR(6) NOT NULL,
    max_hr SMALLINT UNSIGNED NOT NULL,
    exercise_angina CHAR(1) NOT NULL,
    st_slope VARCHAR(5) NOT NULL,
    predicted_heart_disease BOOLEAN NOT NULL,
    model_score DECIMAL(9, 8) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
);
```

The script is deliberately non-destructive: it uses `IF NOT EXISTS` and does not drop or alter the existing `titanic_db` database or its Titanic `predictions` table. This is important because the repository appears to have been repurposed from an earlier Titanic project, and the existing data should not be destroyed by a schema update.

`model_score DECIMAL(9,8)` stores values in [0, 1] with eight decimal places. This is sufficient for the exported leaf probabilities, which have at most 16 significant digits in JSON but are displayed to one decimal place in the UI. If the model were recalibrated to produce values with more precision, the column would need review.

### 6.6 Startup and Environment Management

`Start-HeartHealth.ps1` is a PowerShell wrapper that:

1. Verifies that `TitanicPredictionWeb.csproj` exists.
2. Checks whether port 3306 is already listening.
3. If not, starts the portable MySQL server at `C:\Users\ayush\mysql\mysql-8.4.13-winx64\bin\mysqld.exe` with `my.ini`.
4. Waits up to 30 seconds for the port to become available.
5. Prompts for the MySQL `root` password as a `SecureString`.
6. Converts the password to a BSTR and builds a connection string with `DbConnectionStringBuilder`.
7. Sets `ConnectionStrings__HeartDiseaseDatabase` in the process environment.
8. Runs `dotnet run --project ... --urls "http://127.0.0.1:5188"`.
9. In a `finally` block, removes the environment variable, clears the password from the builder, and zeroes the BSTR.

This is a thoughtful local-development script: the password is not written to disk, and the cleanup reduces the chance of leaving secrets in process memory. It is not a production deployment mechanism. A production system would use a secret manager, a managed database, a reverse proxy, and a proper service supervisor.

### 6.7 Interface Design and Accessibility

The UI is a dark-themed screening console on a single Razor Page, with a distinct visual identity:

- A header with a cardio-signal glyph, a "model online" pill, and an "educational screening tool" note.
- A hero section with a large headline, a short explanation, three metrics (10 inputs, 21 tree nodes, 5 encoders), and an anchor link to the form.
- A signal card with an animated ECG line and a list of the ten features.
- A result card that changes colour and icon for "flagged" versus "clear".
- A score meter that fills in proportion to the model score.
- A two-column form grid with numbered fields, units, and inline validation messages.
- A model note explaining the dataset, the omission of Oldpeak, and the non-diagnostic nature of the tool.
- A footer with the educational disclaimer.

Accessibility features include semantic labels, `aria-live="polite"` on the result card, `role="alert"` on error messages, visible `:focus-visible` outlines, `prefers-reduced-motion` support, and responsive breakpoints at 980 px, 720 px, and 420 px. The colour palette is dark with high-contrast text, but no formal WCAG audit has been performed. The animated ECG is decorative and marked `aria-hidden`.

The UI is visually polished, but the result headline is clinically overconfident: it says "You may have heart disease" or "You do not have heart disease". The latter is especially problematic because a negative screening result does not rule out disease, and the model's specificity is 77.1%. Section 8.4 recommends safer wording.

### 6.8 Error Handling and Graceful Degradation

The application handles three failure modes:

1. **Validation failure.** The page is re-rendered with field-level errors and a validation summary. No prediction is made.
2. **Database failure.** The model result is still displayed, and the user is told that the result could not be saved. The exception is logged.
3. **Missing or invalid configuration.** The repository throws an `InvalidOperationException` with a message that tells the operator to set `ConnectionStrings__HeartDiseaseDatabase`. The page displays this message.

A global exception handler is enabled outside Development, and a custom `Error.cshtml` page shows a "Signal lost" message with a request ID. The request ID can be used to correlate a user report with server logs.

The model service itself throws when it is first constructed if the embedded JSON is missing or inconsistent. This is a fail-fast design: it is better to fail on first use than to serve predictions from a corrupted model.

### 6.9 Security and Privacy Engineering

The current security posture is appropriate for a local educational demo but not for production:

| Control | Status | Comment |
|---|---|---|
| Parameterised SQL | Present | `MySqlParameter` for every value |
| Hard-coded credentials | Absent | Password prompted at runtime |
| Secret in source control | Absent | Connection string is an environment variable |
| HTTPS redirection | Present | `UseHttpsRedirection` |
| HSTS | Present outside Development | `UseHsts` |
| Antiforgery | Present by default | Razor Pages form tag helper |
| Authentication | Absent | No user accounts |
| Authorisation | Absent | Anyone who can reach the port can submit |
| Rate limiting | Absent | No protection against automated submissions |
| Audit log | Partial | Database row with timestamp; no user or IP |
| Data retention policy | Absent | Rows accumulate indefinitely |
| Encryption at rest | Not configured | Depends on MySQL installation |
| Backups | Not configured | Local demo |
| Dependency scanning | Absent | No CI or SCA |
| Penetration testing | Absent | No formal review |

The app stores clinical-style inputs, which are sensitive even without direct identifiers. A production deployment would need a threat model, access control, encryption, retention limits, and a privacy review.

### 6.10 Naming and Technical Debt

The project carries several names from its history:

- Folder and project file: `TitanicPredictionWeb`
- Assembly and namespace: `HeartHealthWeb`
- Web brand: `Cardio Signal`
- README product name: `Heartwise`
- Database: `titanic_db`
- Table: `heart_disease_predictions`

This is a classic example of hidden technical debt in machine-learning systems [12]. The names are not merely cosmetic: they increase the risk of editing the wrong file, confuse new contributors, and make deployment artifacts harder to identify. A future refactor should choose one product name, rename the project and namespace, and either migrate the database or document the legacy name explicitly. The current README does document the `titanic_db` name and the non-destructive migration, which mitigates the risk somewhat.

---

## 7. Results

### 7.1 Selected Model

The grid search selected the following configuration:

| Hyperparameter | Selected value |
|---|---|
| `max_depth` | 4 |
| `min_samples_leaf` | 40 |
| `criterion` | `entropy` |
| Leaf smoothing \(\alpha\) | 3.0 |
| Tree nodes | 21 |
| Leaves | 11 |
| Training rows | 918 |
| Positive rows | 508 |
| Negative rows | 410 |

The tree has 21 nodes, of which 10 are internal split nodes and 11 are leaves. The maximum depth is 4, so inference requires at most four comparisons. The model JSON is 1,785 bytes.

### 7.2 Cross-Validated Performance

The pooled out-of-fold performance of the selected model is:

| Metric | Value | Interpretation |
|---|---:|---|
| Accuracy | 0.8224 | 82.2% of all cases correctly classified at 0.5 |
| ROC AUC | 0.8933 | Good discrimination on internal cross-validation |
| Log loss | 0.3992 | Moderate probabilistic error; better than a 0.5 baseline |
| Brier score | 0.1242 | Mean squared probability error of 0.124 |
| 95% bootstrap interval for accuracy | 0.7974–0.8464 | Descriptive sampling interval |
| 95% bootstrap interval for AUC | 0.8709–0.9141 | Descriptive sampling interval |

These values match the metadata exported in `heart-disease-model.json`: `logLoss: 0.399161`, `rocAuc: 0.893319`, `accuracy: 0.82244`, `brier: 0.124235`. The small differences in the table are due to rounding.

The bootstrap intervals are computed from the out-of-fold predictions and therefore describe the uncertainty of the evaluation sample. They do not account for the fact that the model configuration was selected on the same data, nor for variability in the training process. A nested cross-validation or a held-out external cohort would be needed for a less biased estimate.

### 7.3 Confusion Matrix and Operating Characteristics

At the 0.5 threshold, the pooled out-of-fold confusion matrix is:

|  | Predicted negative | Predicted positive |
|---|---:|---:|
| **Actual negative** | 316 (TN) | 94 (FP) |
| **Actual positive** | 69 (FN) | 439 (TP) |

Derived operating characteristics:

| Metric | Value |
|---|---:|
| Sensitivity (recall) | 0.8642 |
| Specificity | 0.7707 |
| Positive predictive value (precision) | 0.8236 |
| Negative predictive value | 0.8208 |
| False-positive rate | 0.2293 |
| False-negative rate | 0.1358 |

The model is more sensitive than specific: it catches 86.4% of positive cases but flags 22.9% of negative cases. For a screening-oriented tool, this trade-off may be reasonable, but it depends on the clinical context and the cost of false positives (additional tests, anxiety) versus false negatives (missed disease). The 0.5 threshold is a default, not a clinically optimised operating point.

### 7.4 Calibration

The out-of-fold calibration table is:

| Score bin | \(n\) | Mean predicted score | Observed positive rate |
|---|---:|---:|---:|
| 0.0–0.2 | 215 | 0.067 | 0.037 |
| 0.2–0.4 | 131 | 0.297 | 0.344 |
| 0.4–0.6 | 110 | 0.493 | 0.473 |
| 0.6–0.8 | 119 | 0.742 | 0.824 |
| 0.8–1.0 | 343 | 0.900 | 0.889 |

The calibration is reasonable for a small, single-tree model. The lowest bin is slightly overconfident in the negative direction (predicted 0.067, observed 0.037), the 0.2–0.4 bin is slightly underconfident (0.297 vs 0.344), and the 0.6–0.8 bin is underconfident (0.742 vs 0.824). The largest bin, 0.8–1.0, is well calibrated (0.900 vs 0.889). With only five bins and 918 rows, these differences are descriptive and should not be over-interpreted.

The calibration table does not mean that an individual score of 0.9 is a 90% personal probability of disease. It means that, in this evaluation sample, patients whose scores fell in the 0.8–1.0 bin had an observed positive rate of 88.9%. Individual risk depends on factors not in the dataset, and the model has not been externally validated.

### 7.5 Comparison with the Legacy Pipeline

The legacy `pipe.pkl` is a fully grown decision tree with a `ColumnTransformer`, `MinMaxScaler`, `SelectKBest(chi2, k=10)`, and `DecisionTreeClassifier(random_state=42)`. It is evaluated on the ten-feature input (without Oldpeak) because that is the input the deployed application supports; the saved notebook's column indexing is ambiguous about whether Oldpeak is included, while the serialized pipeline works with ten columns. This inconsistency is itself a reproducibility lesson. Under the same stratified five-fold cross-validation protocol, the legacy pipeline achieves:

| Metric | Legacy `pipe.pkl` | Deployed shallow tree |
|---|---:|---:|
| CV accuracy | 0.7995 | **0.8224** |
| CV ROC AUC | 0.7989 | **0.8933** |
| CV Brier score | 0.2005 | **0.1242** |
| Tree depth | 12 | **4** |
| Leaves | 123 | **11** |
| Nodes | 245 | **21** |
| Distinct probability values | 2 | **11** |

The legacy tree is much larger and produces only 0/1 probabilities, because its leaves are pure. Its log loss is therefore extremely high (the evaluation clips probabilities, but the underlying issue is the same). On the original 20% hold-out split (seed 42), the legacy pipeline achieves 0.962 accuracy and 0.962 AUC, while the deployed configuration achieves 0.804 accuracy and 0.887 AUC. This apparent contradiction is instructive: a single hold-out split can favour a high-variance model by chance. The five-fold cross-validation tells a more stable story, with the legacy tree averaging 0.7995 accuracy and the shallow tree 0.8224.

The deployed model is therefore not a regression in expected performance. It trades accuracy on this particular hold-out split for better cross-validated discrimination, much better probability quality, and a model that can be explained in a short conversation.

### 7.6 Ablation Studies

Two exploratory ablations were run under the same preprocessing and grid-search protocol:

| Feature set | CV log loss | CV AUC | CV accuracy | CV Brier | Selected tree |
|---|---:|---:|---:|---:|---|
| Ten features (deployed) | **0.3992** | 0.8933 | 0.8224 | **0.1242** | Depth 4, 21 nodes, 11 leaves |
| Ten features + `Oldpeak` | 0.4012 | 0.8931 | 0.8257 | 0.1266 | Depth 4, 19 nodes, 10 leaves |
| Nine features (without `Cholesterol`) | **0.3960** | **0.8977** | **0.8410** | **0.1219** | Depth 5, 35 nodes, 18 leaves |

Adding `Oldpeak` did not improve log loss or AUC in this protocol; it slightly improved accuracy but worsened Brier score and selected a different criterion (`gini`). This supports the design decision to omit a variable the web form does not collect, at least for this dataset and model family. It does not prove that Oldpeak is clinically unimportant; it may matter more in a larger sample, a different model class, or a population with more ST-depression variation.

Removing `Cholesterol` improved all four metrics in this protocol, despite selecting a larger tree (depth 5, 35 nodes, 18 leaves). This is consistent with the fact that the deployed tree never splits on cholesterol. However, the improvement is small and the ablation changes the model-selection path, so it should be treated as a hypothesis for further study rather than a recommendation to stop collecting cholesterol. The high proportion of zero/missing cholesterol values may attenuate its apparent value.

### 7.7 Decision-Tree Structure

The exported tree can be read as the following rule set. The scores are smoothed leaf positive rates; the thresholds are expressed in clinically meaningful raw units where possible.

```text
ST_Slope = Flat?
├── Yes
│   ├── Sex = Male?
│   │   ├── ChestPainType = ASY?
│   │   │   ├── FastingBS = 0  →  0.908
│   │   │   └── FastingBS = 1  →  0.967
│   │   └── ChestPainType ≠ ASY?
│   │       ├── MaxHR ≤ 130.5  →  0.863
│   │       └── MaxHR > 130.5  →  0.625
│   └── Sex = Female          →  0.519
└── No (Up or Down)
    ├── ChestPainType = ASY?
    │   ├── ExerciseAngina = Yes  →  0.812
    │   └── ExerciseAngina = No?
    │       ├── RestingBP ≤ 125.5 →  0.526
    │       └── RestingBP > 125.5 →  0.241
    └── ChestPainType ≠ ASY?
        ├── Age ≤ 56.5?
        │   ├── RestingBP ≤ 119  →  0.170
        │   └── RestingBP > 119  →  0.033
        └── Age > 56.5           →  0.268
```

The tree uses eight of the ten inputs:

| Feature | Number of split nodes |
|---|---:|
| `ChestPainType` | 2 |
| `RestingBP` | 2 |
| `ST_Slope` | 1 |
| `Sex` | 1 |
| `FastingBS` | 1 |
| `MaxHR` | 1 |
| `ExerciseAngina` | 1 |
| `Age` | 1 |
| `Cholesterol` | 0 |
| `RestingECG` | 0 |

`Cholesterol` and `RestingECG` are collected by the form but never used by the fitted tree. This is not a bug: the tree found other splits more informative. It does mean that the model's behaviour can be explained without discussing those two inputs, and that their collection burden is not justified by this particular fit.

The root split is `ST_Slope = Flat`. Flat ST slope is associated with a much higher risk than upsloping or downsloping in this dataset. The next split is sex: among flat-slope patients, males have higher risk than females. Among males with flat slope, asymptomatic chest pain (`ASY`) is the highest-risk category, and fasting blood sugar above 120 mg/dL pushes the score slightly higher. Among males with flat slope and non-ASY chest pain, a maximum heart rate above 130.5 bpm lowers the score from 0.863 to 0.625.

For non-flat slopes, asymptomatic chest pain again identifies a high-risk group, but the branch depends on exercise angina and resting blood pressure: among these patients, exercise-induced angina is associated with a score of 0.812, whereas the absence of angina with resting blood pressure above 125.5 is associated with a much lower score of 0.241. In the non-ASY, non-flat branch, the tree first splits on age at 56.5 and then on resting blood pressure among younger patients; the leaf with age ≤ 56.5 and blood pressure > 119 has the lowest score (0.033), while age > 56.5 has a higher score (0.268). These are conditional associations in a small sample, not causal effects, and they illustrate why tree rules should not be read as biological mechanisms.

### 7.8 Leaf-Level Risk Profile

The 11 leaves, their training counts, observed positive rates, and smoothed scores are:

| Leaf | \(n\) | Positives | Observed rate | Smoothed score | Risk tier |
|---:|---:|---:|---:|---:|---|
| 19 | 174 | 3 | 0.0172 | 0.0333 | Low |
| 18 | 41 | 5 | 0.1220 | 0.1702 | Low |
| 15 | 48 | 10 | 0.2083 | 0.2407 | Low |
| 20 | 65 | 16 | 0.2462 | 0.2676 | Intermediate |
| 9 | 75 | 39 | 0.5200 | 0.5185 | Intermediate |
| 14 | 51 | 27 | 0.5294 | 0.5263 | Intermediate |
| 8 | 66 | 42 | 0.6364 | 0.6250 | Intermediate |
| 12 | 79 | 66 | 0.8354 | 0.8118 | High |
| 7 | 45 | 41 | 0.9111 | 0.8627 | High |
| 4 | 189 | 174 | 0.9206 | 0.9077 | High |
| 5 | 85 | 85 | 1.0000 | 0.9670 | High |

The smoothing is visible in the extreme leaves: leaf 19 has an observed rate of 1.72% but a smoothed score of 3.33%; leaf 5 has an observed rate of 100% but a smoothed score of 96.70%. The shrinkage is modest because the leaves are reasonably large, but it prevents the model from claiming absolute certainty.

The risk tiers are descriptive, not clinical categories. A score below 0.25 is labelled "low" here only for discussion; the application itself uses a single 0.5 threshold for the flag.

### 7.9 Example Predictions

The following profiles illustrate the model's behaviour. They are synthetic combinations, not real patients.

| Profile | Key inputs | Score | Flag at 0.5 |
|---|---|---:|---|
| Form defaults | Age 45, male, ATA, BP 120, cholesterol 200, fasting BS 0, normal ECG, max HR 150, no angina, upsloping ST | 3.3% | Clear |
| Low-risk female | Age 35, female, NAP, BP 110, cholesterol 180, fasting BS 0, normal ECG, max HR 170, no angina, upsloping ST | 17.0% | Clear |
| Typical angina, 60M | Age 60, male, TA, BP 150, cholesterol 280, fasting BS 0, LVH, max HR 110, exercise angina, downsloping ST | 26.8% | Clear |
| High-risk ASY | Age 58, male, ASY, BP 128, cholesterol 259, fasting BS 0, LVH, max HR 130, exercise angina, flat ST | 90.8% | Flagged |
| Asymptomatic 55M | Age 55, male, ASY, BP 140, cholesterol 240, fasting BS 1, ST abnormality, max HR 120, exercise angina, flat ST | 96.7% | Flagged |

The form defaults produce a very low score because they combine a young age, normal blood pressure, normal ECG, high maximum heart rate, no exercise angina, and an upsloping ST segment. The high-risk profiles combine flat ST slope, asymptomatic chest pain, male sex, and either elevated fasting blood sugar or lower maximum heart rate. These outputs are consistent with the tree structure, but they are not clinical predictions.

### 7.10 In-Sample Replay and Export Verification

A replay of the exported JSON on all 918 training rows produced:

| Metric | In-sample value |
|---|---:|
| Accuracy | 0.8366 |
| ROC AUC | 0.9167 |
| Log loss | 0.3573 |
| Brier score | 0.1120 |
| Confusion matrix | TN 294, FP 116, FN 34, TP 474 |

These values are higher than the cross-validated values, as expected for in-sample evaluation. They are useful only as a sanity check that the exported model reproduces the fitted tree; they are not evidence of generalisation.

The round-trip check compared the JSON traversal with scikit-learn's leaf assignments for every training row and found **918/918 matches** at \(10^{-12}\) tolerance. This confirms that the C#-compatible representation preserves the fitted tree exactly, including the scaler and category mappings.

### 7.11 Runtime Characteristics

The production inference path has the following characteristics:

| Property | Value |
|---|---|
| Model size | 1,785 bytes JSON |
| Tree depth | 4 |
| Maximum comparisons per prediction | 4 |
| Python runtime required | No |
| scikit-learn runtime required | No |
| Model load time | Once at singleton construction |
| Per-request model work | Encode 5 categories, scale 10 values, traverse ≤4 nodes |
| Database work | One parameterised INSERT per valid submission |
| Persistence failure behaviour | Result still displayed; error message shown |

The model is small enough to embed in the assembly and fast enough that inference latency is negligible relative to database and network costs. The main runtime risk is not model speed but configuration: a missing connection string or an unavailable MySQL server prevents persistence, though not prediction.

---

## 8. Discussion

### 8.1 Principal Findings

The project demonstrates that a shallow, smoothed decision tree can be a credible educational screening demo. On internal five-fold cross-validation, the selected tree achieved 0.822 accuracy, 0.893 AUC, 0.399 log loss, and 0.124 Brier score. It produced eleven graded risk levels, used eight of the ten inputs, and was small enough to embed as a 1,785-byte JSON file. The legacy fully grown pipeline was larger (245 nodes, 123 leaves) and produced only two probability values; its cross-validated accuracy and AUC were lower (0.800 and 0.799), and its Brier score was substantially worse (0.201).

The engineering contribution is equally important: the project shows a complete path from a CSV to a running web app with a stable inference contract, server-side validation, parameterised persistence, and a non-destructive database migration. The model is not a pickle loaded at runtime; it is a transparent set of arrays and scalars that can be inspected, diffed, and reimplemented in another language.

### 8.2 Interpretability and Clinical Plausibility

The tree's main splits are clinically plausible:

- **Flat ST slope** is associated with higher risk than upsloping or downsloping ST segments in this dataset.
- **Male sex** is associated with higher risk among flat-slope patients.
- **Asymptomatic chest pain (`ASY`)** is generally associated with higher risk than non-anginal, atypical, or typical angina in this sample, which may reflect referral patterns and the fact that asymptomatic patients in the dataset may have been investigated for other reasons.
- **Exercise-induced angina** is associated with higher risk in the non-flat branch, and **lower maximum heart rate** is associated with higher risk in the flat, non-ASY male branch.
- **Higher fasting blood sugar** slightly increases risk among flat-slope, asymptomatic males.
- **Age** and **resting blood pressure** appear in the non-ASY, non-flat branch, with interactions that are not straightforwardly monotonic.

The tree does not use cholesterol or resting ECG. This is a useful reminder that a model's feature importance is not the same as clinical importance. Cholesterol is a well-established risk factor, but in this dataset its values are heavily missing (18.7% zeros), and the tree may find other variables more useful for the splits it can make. Resting ECG may be redundant with ST slope and chest-pain type in this small sample.

The non-monotonic branch for age and blood pressure is a caution against over-interpreting tree rules. A depth-4 tree can only represent a coarse partition; the fact that older age is associated with lower risk in one leaf does not mean that ageing is protective. It means that, conditional on the other splits, the data in that leaf had a lower positive rate. Causal language should be avoided.

### 8.3 The Cholesterol Paradox

The most striking ablation result is that removing cholesterol improved all four cross-validated metrics and selected a larger tree. There are several possible explanations:

1. **Missingness.** 18.7% of cholesterol values are zero and were imputed. Imputation reduces variance and may distort the relationship.
2. **Correlation with other features.** Cholesterol may be correlated with age, sex, blood pressure, or chest-pain type, so the tree can capture its signal through other splits.
3. **Non-linearity.** Cholesterol risk is not necessarily monotonic; very low cholesterol can indicate frailty or malnutrition, and very high cholesterol can indicate familial hypercholesterolaemia. A shallow tree may not capture this.
4. **Sample size.** With 918 rows and a depth limit, the tree may not have enough data to justify a cholesterol split.
5. **Random variation.** The improvement is small (0.003 in log loss) and could be noise.

The practical implication is not "stop measuring cholesterol". It is that feature collection should be justified by external evidence, not only by one tree's splits. A future study should compare a pre-specified feature set with and without cholesterol in a larger, externally validated cohort.

### 8.4 Calibration and Communication

The model's calibration is reasonable but not perfect. The lowest bin is slightly overconfident, the middle bins are close, and the highest bin is well calibrated. The Brier score of 0.124 is better than the legacy pipeline's 0.201, but it is not a clinical validation.

The user interface communicates risk in two ways: a numeric score with a meter, and a headline that says "You may have heart disease" or "You do not have heart disease". The numeric score is appropriately caveated: the page says it is not a personal clinical probability. The headline is not. A negative result from a model with 77.1% specificity and 82.1% NPV does not mean the patient does not have heart disease. A safer design would say:

- **Flagged:** "The model found a pattern associated with higher risk. This is not a diagnosis; discuss it with a clinician."
- **Clear:** "The model did not find a high-risk pattern. This does not rule out heart disease; seek care if you have symptoms."

The threshold could also be made explicit and configurable. A screening programme might choose a lower threshold to increase sensitivity, accepting more false positives. A confirmatory setting might choose a higher threshold. The current 0.5 threshold is a default, not a clinical decision.

Finally, the score is a leaf class share, not a calibrated individual probability. The Beta smoothing improves the behaviour of extreme leaves, but it does not perform post-hoc calibration (Platt scaling, isotonic regression) or account for individual uncertainty. A future version could add a calibration layer and report a prediction interval, while being careful not to imply more certainty than the data support.

### 8.5 Dataset and Methodological Limitations

The study has several important limitations:

1. **Retrospective, secondary data.** The dataset was collected for other purposes and is used here without a prospective protocol.
2. **Single dataset.** There is no external validation on a different hospital, country, or time period. The internal cross-validation may overstate performance.
3. **Small sample.** 918 rows is modest for a clinical prediction model, especially when splitting into subgroups by sex, chest-pain type, and ST slope.
4. **Sex imbalance.** 79% of records are male. Performance in women is estimated from a small subgroup and may be unstable.
5. **Missingness.** Cholesterol zeros are treated as missing and imputed; the missingness mechanism may not be random.
6. **Label definition.** The target is a binary indicator derived from the source dataset; the exact diagnostic criteria and adjudication process are not documented in the repository.
7. **No site indicator.** The four source centres are pooled. Site-specific effects may confound the model.
8. **No temporal validation.** The data are historical; clinical practice and population characteristics may have changed.
9. **Selection bias.** Patients who underwent angiography or exercise testing are not representative of the general population.
10. **No competing risks.** The model predicts a binary label, not time-to-event or cause-specific risk.
11. **No fairness analysis.** Performance by sex, age group, and other subgroups is not reported.
12. **No decision-curve analysis.** The clinical net benefit of the model at different thresholds is unknown [13].
13. **No nested cross-validation.** The same folds are used for model selection and performance reporting, so the metrics are optimistically biased.
14. **Single tree.** A single tree is high-variance; a random forest or gradient-boosted model might discriminate better, at the cost of interpretability.
15. **No post-hoc calibration.** Beta smoothing is not a substitute for a calibration curve fitted on held-out data.
16. **No uncertainty quantification.** The model returns a point score, not a confidence interval.

These limitations do not invalidate the educational contribution, but they rule out clinical claims.

### 8.6 Engineering Limitations

The implementation is a well-structured demo, but it lacks several production controls:

- **No automated tests.** There are no unit tests for encoding, scaling, tree traversal, validation, or repository behaviour. The round-trip check in the training script is valuable but not part of a CI pipeline.
- **No CI/CD.** There is no build pipeline, no automated deployment, and no regression testing on model updates.
- **No database migrations.** The schema is created by a single SQL script. There is no versioned migration tool.
- **No authentication or authorisation.** Anyone who can reach the app can submit data.
- **No rate limiting.** Automated submissions could fill the table.
- **No audit trail.** The database row has a timestamp but no user, IP, or request ID.
- **No retention policy.** Records accumulate indefinitely.
- **No monitoring or alerting.** There are no metrics for latency, error rate, or data drift.
- **No model registry.** The model JSON is embedded in the assembly; there is no version history beyond Git.
- **No rollback plan.** Reverting a model requires redeploying the assembly.
- **No containerisation.** The app depends on a local MySQL installation and a Windows PowerShell script.
- **No secret manager.** The connection string is passed through an environment variable, which is better than source code but not a full secret-management solution.
- **No accessibility audit.** The UI has good practices but no formal WCAG testing.
- **No load testing.** Performance under concurrent submissions is unknown.

These are typical gaps in a student project and should be addressed before any real deployment.

### 8.7 Ethical, Legal, and Social Considerations

A heart-disease prediction tool touches sensitive health data and high-stakes decisions. The following issues deserve explicit attention:

1. **Not a medical device.** The app is an educational demo. It has not been cleared or approved by the FDA, the European Medicines Agency, or any other regulator. It should not be marketed as a diagnostic or screening device.
2. **Clinician oversight.** Any use with patients should be supervised by a qualified clinician who can interpret the result in context.
3. **Informed consent.** If real patient data are stored, users should be informed about what is collected, why, how long it is retained, and who can access it.
4. **Privacy and security.** The app stores clinical-style inputs. A production system needs encryption, access control, audit logging, and a privacy impact assessment.
5. **Bias and fairness.** The dataset is 79% male and drawn from four historical centres. Performance and calibration may differ by sex, age, ethnicity, and socioeconomic status. These differences have not been measured.
6. **Automation bias.** A polished interface and a numeric score can encourage over-reliance. The disclaimers help, but the headline wording works against them.
7. **Distributive justice.** A tool trained on one population may not generalise to under-represented groups. Deploying it without validation could widen health disparities [14].
8. **Liability.** If a user acts on a false negative, who is responsible? The current disclaimers are necessary but not sufficient for clinical deployment.
9. **Data provenance.** The dataset's license and preprocessing history should be documented before redistribution.
10. **Environmental and maintenance cost.** Even a small model requires hosting, monitoring, and maintenance. These costs should be justified by a clear use case.

### 8.8 Threats to Validity

- **Internal validity.** The preprocessing is fitted inside each fold, which reduces leakage. However, the model selection uses the same folds as the performance estimate, so the reported metrics are optimistically biased. The round-trip check confirms implementation correctness, not statistical validity.
- **External validity.** The model has not been tested on a different cohort. Its performance in other hospitals, countries, or time periods is unknown.
- **Construct validity.** The target is a binary label derived from the source data. It may not correspond exactly to the clinical outcome a user cares about (e.g., myocardial infarction, cardiovascular death, or need for revascularisation).
- **Conclusion validity.** The bootstrap intervals describe sampling variability but not model-selection variability. The ablation comparisons are exploratory and not corrected for multiple comparisons.
- **Ecological validity.** The web form collects a small subset of clinical information. Real decisions use history, examination, biomarkers, imaging, and patient preferences.

### 8.9 Recommendations

For the project to move from educational demo to credible research artifact, the following steps are recommended:

1. **Rename the project.** Choose one name and apply it consistently to the folder, assembly, namespace, database, and UI.
2. **Add a model card.** Document intended use, training data, features, metrics, limitations, and ethical considerations.
3. **Add automated tests.** Cover encoding, scaling, tree traversal, validation, repository behaviour, and the JSON contract.
4. **Add CI.** Build, test, and verify the model round-trip on every commit.
5. **Pin dependencies.** Add a `requirements.txt` or lock file for the training environment and a `global.json` for .NET.
6. **Perform external validation.** Test on a separate cohort or a held-out centre before making performance claims.
7. **Add calibration and decision-curve analysis.** Report calibration curves and net benefit across thresholds.
8. **Analyse fairness.** Report performance by sex, age group, and other available subgroups.
9. **Improve the wording.** Replace diagnostic headlines with risk-pattern language and make the threshold explicit.
10. **Add governance.** Authentication, authorisation, audit logging, retention limits, and a privacy review are prerequisites for real patient data.
11. **Containerise and monitor.** Use a reproducible deployment artifact and add latency, error-rate, and drift monitoring.
12. **Document the data license.** Include the UCI/Kaggle terms and a data dictionary.

---

## 9. Reproducibility and Availability

### 9.1 Environment

The following environment was used to produce the results in this paper:

| Component | Version / path |
|---|---|
| Python | 3.13 |
| pandas | 3.1.0 |
| NumPy | 2.5.4 |
| scikit-learn | 1.9.1 |
| .NET SDK | 8.0 |
| MySqlConnector | 2.6.2 |
| MySQL | 8.4.13 |
| OS | Windows |
| Project root | `C:\Users\ayush\Downloads\New folder (3)\New folder (3)` |

The legacy `pipe.pkl` was created with scikit-learn 1.6.1. Loading it with 1.9.1 produces `InconsistentVersionWarning` messages. The deployed model does not load the pickle, so this warning does not affect production inference. It does affect any attempt to reproduce the legacy pipeline exactly.

### 9.2 Commands

Create and activate the Python environment:

```powershell
cd "C:\Users\ayush\Downloads\New folder (3)\New folder (3)"
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install pandas numpy scikit-learn
```

Retrain and export the model:

```powershell
python train_heart_model.py
```

Initialise the database (the script prompts for the MySQL root password):

```powershell
& "C:\Users\ayush\mysql\mysql-8.4.13-winx64\bin\mysql.exe" `
  --protocol=TCP -h localhost -P 3306 -u root -p `
  -e "source C:/Users/ayush/Downloads/New folder (3)/New folder (3)/TitanicPredictionWeb/database/init.sql"
```

Start the website:

```powershell
.\TitanicPredictionWeb\Start-HeartHealth.ps1
```

Open `http://127.0.0.1:5188`.

### 9.3 Artifacts

| Artifact | Description |
|---|---|
| `heart.csv` | Input dataset |
| `train_heart_model.py` | Reproducible training and export script |
| `TitanicPredictionWeb/Models/heart-disease-model.json` | Deployed model contract |
| `pipe.pkl` | Legacy pipeline, kept for comparison |
| `predict_heart_disease.ipynb` | Original exploratory notebook |
| `predict_heartpart2.ipynb` | Legacy inference example |
| `TitanicPredictionWeb/database/init.sql` | Database schema |
| `TitanicPredictionWeb/Start-HeartHealth.ps1` | Local startup automation |

### 9.4 Version Drift

The main reproducibility risk is version drift. The training script depends on pandas, NumPy, and scikit-learn, but the repository does not pin their versions. A future run with a different scikit-learn version could produce a different tree, different leaf probabilities, and slightly different metrics. The model JSON includes training metadata and metrics, which helps detect a mismatch, but it does not enforce the environment.

Recommended controls:

- Add a `requirements.txt` with exact versions.
- Add a `global.json` for the .NET SDK.
- Record the Python and package versions in the model JSON.
- Add a CI job that retrains and compares the exported JSON with the committed artifact.
- Store model versions in a registry or Git tag.

---

## 10. Future Work

### 10.1 Modelling

- **External validation** on a separate cohort, ideally from a different country and time period.
- **Nested cross-validation** to separate model selection from performance estimation.
- **Repeated cross-validation** to quantify split variability.
- **Calibration layer** using Platt scaling or isotonic regression on held-out data.
- **Decision-curve analysis** to estimate net benefit across thresholds [13].
- **Cost-sensitive thresholds** that reflect the relative cost of false positives and false negatives.
- **Fairness analysis** by sex, age group, and other available subgroups.
- **Feature engineering** for cholesterol (e.g., missingness indicator, non-linear terms) and blood pressure.
- **Comparison with ensemble models** (random forest, gradient boosting) to quantify the interpretability–performance trade-off.
- **SHAP or local explanations** for individual predictions, while recognising that a depth-4 tree is already globally interpretable [15].
- **Monotonic constraints** for features with known directional effects, where clinically justified.
- **Survival or time-to-event modelling** if longitudinal outcomes become available.

### 10.2 Evaluation

- **Prospective evaluation** in a clinical workflow, with clinician review and patient follow-up.
- **Usability testing** with patients and clinicians, including comprehension of risk language.
- **Health-economic evaluation** of the cost per additional case detected.
- **Equity evaluation** to ensure that performance is not worse for under-represented groups.
- **Model drift monitoring** after deployment.

### 10.3 Engineering

- **Automated tests** for preprocessing, inference, validation, and persistence.
- **CI/CD** with build, test, and model round-trip checks.
- **Containerisation** with Docker Compose for the app and MySQL.
- **Database migrations** using a versioned tool.
- **Authentication and authorisation** for any non-local deployment.
- **Rate limiting and abuse prevention.**
- **Audit logging** with request IDs and user context.
- **Data retention and deletion** workflows.
- **Model registry and versioning** with rollback.
- **Monitoring** for latency, errors, data drift, and prediction drift.
- **Accessibility audit** against WCAG 2.2.
- **Internationalisation** and localisation if used beyond the current context.
- **API endpoint** for programmatic access, with the same validation and audit controls.

### 10.4 Clinical Translation

- **Clinician co-design** of the interface and risk communication.
- **Regulatory assessment** to determine whether the intended use makes the software a medical device.
- **Clinical safety case** and hazard analysis.
- **Informed consent and privacy impact assessment.**
- **Pilot study** with a pre-specified protocol and stopping rules.
- **Post-market surveillance** if the tool is ever deployed.

---

## 11. Conclusion

Heartwise / Cardio Signal is a small but complete example of how a public clinical dataset can be turned into an interpretable, deployable web application. The project's most important design choice is restraint: instead of exporting a fully grown tree with 123 leaves and binary outputs, it searches for a shallow tree with 11 leaves and smooths the leaf probabilities with a Beta prior. The resulting model is easier to explain, better calibrated on internal cross-validation, and small enough to embed as a 1,785-byte JSON file. The legacy pipeline is larger and produces only 0%/100% scores; the deployed tree achieves higher cross-validated accuracy (0.822 vs 0.800), AUC (0.893 vs 0.799), and Brier score (0.124 vs 0.201).

The engineering work is equally important. The app validates inputs, encodes and scales them consistently, traverses the tree in C#, persists results with parameterised SQL, degrades gracefully when MySQL is unavailable, and documents its own model contract. The round-trip check confirms that the JSON representation reproduces the fitted tree for all 918 training rows.

The project also has clear limitations. It is trained on a single retrospective dataset, has not been externally validated, is heavily male, omits Oldpeak, never splits on cholesterol, and reports a leaf class share rather than a calibrated individual probability. Its result headline is more diagnostic than the evidence warrants. It lacks automated tests, authentication, monitoring, and a retention policy. These are not reasons to dismiss the work; they are the agenda for the next stage.

The broader lesson is that interpretable models and careful engineering are complementary. A shallow tree is not automatically trustworthy, and a polished web app is not automatically clinically useful. Trust comes from transparent data handling, honest evaluation, clear communication, external validation, and governance. This project takes several meaningful steps in that direction and documents the remaining distance.

---

## Acknowledgments

The project builds on the UCI Heart Disease dataset and the open-source scikit-learn, pandas, NumPy, ASP.NET Core, and MySqlConnector communities. The repository's Git history records the initial commit and an "Upload heart prediction projects" commit by Ayush Maurya, with co-authorship metadata for GitHub Copilot. No external funding is reported in the repository.

---

## References

[1] World Health Organization. *Cardiovascular diseases (CVDs)*. Fact sheet, 2021. <https://www.who.int/news-room/fact-sheets/detail/cardiovascular-diseases-(cvds)>

[2] D'Agostino, R. B., Sr., Vasan, R. S., Pencina, M. J., et al. (2008). General cardiovascular risk profile for use in primary care: the Framingham Heart Study. *Circulation*, 117(6), 743–753.

[3] Janosi, A., Steinbrunn, W., Pfisterer, M., & Detrano, R. (1988). *Heart Disease*. UCI Machine Learning Repository. DOI: 10.24432/C52P4X.

[4] Detrano, R., Janosi, A., Steinbrunn, W., et al. (1989). International application of a new probability algorithm for the diagnosis of coronary artery disease. *American Journal of Cardiology*, 64(5), 304–310.

[5] fedesoriano. (2021). *Heart Failure Prediction Dataset*. Kaggle. <https://www.kaggle.com/datasets/fedesoriano/heart-failure-prediction>

[6] Breiman, L., Friedman, J. H., Olshen, R. A., & Stone, C. J. (1984). *Classification and Regression Trees*. Wadsworth.

[7] Hastie, T., Tibshirani, R., & Friedman, J. (2009). *The Elements of Statistical Learning: Data Mining, Inference, and Prediction* (2nd ed.). Springer.

[8] Brier, G. W. (1950). Verification of forecasts expressed in terms of probability. *Monthly Weather Review*, 78(1), 1–3.

[9] Van Calster, B., McLernon, D. J., van Smeden, M., Wynants, L., & Steyerberg, E. W. (2019). Calibration: the Achilles heel of predictive analytics. *BMC Medicine*, 17, 230.

[10] Collins, G. S., Reitsma, J. B., Altman, D. G., & Moons, K. G. M. (2015). Transparent reporting of a multivariable prediction model for individual prognosis or diagnosis (TRIPOD): the TRIPOD statement. *Annals of Internal Medicine*, 162(1), 55–63.

[11] Wolff, R. F., Moons, K. G. M., Riley, R. D., et al. (2019). PROBAST: a tool to assess the risk of bias and applicability of prediction model studies. *Annals of Internal Medicine*, 170(1), 51–58.

[12] Sculley, D., Holt, G., Golovin, D., et al. (2015). Hidden technical debt in machine learning systems. *Advances in Neural Information Processing Systems*, 28, 2503–2511.

[13] Vickers, A. J., & Elkin, E. B. (2006). Decision curve analysis: a novel method for evaluating prediction models. *Medical Decision Making*, 26(6), 565–574.

[14] Obermeyer, Z., Powers, B., Vogeli, C., & Mullainathan, S. (2019). Dissecting racial bias in an algorithm used to manage the health of populations. *Science*, 366(6464), 447–453.

[15] Lundberg, S. M., & Lee, S.-I. (2017). A unified approach to interpreting model predictions. *Advances in Neural Information Processing Systems*, 30, 4765–4774.

[16] Pedregosa, F., Varoquaux, G., Gramfort, A., et al. (2011). Scikit-learn: Machine learning in Python. *Journal of Machine Learning Research*, 12, 2825–2830.

[17] Microsoft. *ASP.NET Core Razor Pages*. Microsoft Learn. <https://learn.microsoft.com/aspnet/core/razor-pages/>

[18] MySqlConnector. *MySqlConnector documentation*. <https://mysqlconnector.net/>

[19] Oracle. *MySQL 8.4 Reference Manual*. <https://dev.mysql.com/doc/refman/8.4/en/>

[20] James, G., Witten, D., Hastie, T., & Tibshirani, R. (2021). *An Introduction to Statistical Learning with Applications in R* (2nd ed.). Springer.

---

## Appendix A: File Inventory

| File | Lines / size | Role |
|---|---|---|
| `heart.csv` | 918 data rows, 35,921 bytes | Dataset |
| `train_heart_model.py` | 412 lines | Training, selection, export, verification |
| `predict_heart_disease.ipynb` | ~66 KB | Original exploratory notebook |
| `predict_heartpart2.ipynb` | ~3 KB | Legacy single-profile inference |
| `pipe.pkl` | 24,469 bytes | Legacy serialized pipeline |
| `TitanicPredictionWeb/Models/heart-disease-model.json` | 1,785 bytes | Deployed model |
| `TitanicPredictionWeb/Program.cs` | 22 lines | App bootstrap |
| `TitanicPredictionWeb/Models/HeartDiseaseInput.cs` | 49 lines | Input DTO and validation |
| `TitanicPredictionWeb/Models/HeartDiseasePredictionResult.cs` | 3 lines | Output record |
| `TitanicPredictionWeb/Services/HeartDiseasePredictionService.cs` | 113 lines | Inference engine |
| `TitanicPredictionWeb/Services/HeartDiseaseRepository.cs` | 45 lines | MySQL persistence |
| `TitanicPredictionWeb/Pages/Index.cshtml` | 254 lines | Form and result UI |
| `TitanicPredictionWeb/Pages/Index.cshtml.cs` | 52 lines | Page handler |
| `TitanicPredictionWeb/Pages/Error.cshtml` | 47 lines | Error page |
| `TitanicPredictionWeb/wwwroot/css/site.css` | 1,146 lines | Styling and responsive design |
| `TitanicPredictionWeb/database/init.sql` | 23 lines | Schema |
| `TitanicPredictionWeb/Start-HeartHealth.ps1` | 62 lines | Local startup |
| `.vscode/tasks.json` | 44 lines | VS Code tasks |

---

## Appendix B: Model JSON Contract

The deployed model is a JSON object with the following top-level fields:

| Field | Type | Meaning |
|---|---|---|
| `sourceModel` | string | Human-readable provenance |
| `inputFeatures` | string array | The ten user-facing input names |
| `encodedCategories` | object | Category order for each categorical feature |
| `transformerOutputFeatures` | string array | The order of the transformed vector |
| `scalerScales` | number array (10) | Multiplicative MinMax parameters |
| `scalerOffsets` | number array (10) | Additive MinMax parameters |
| `selectedFeatures` | boolean array (10) | Feature mask (all true in this model) |
| `childrenLeft` | integer array (21) | Left child index per node; `-1` for leaf |
| `childrenRight` | integer array (21) | Right child index per node; `-1` for leaf |
| `splitFeatures` | integer array (21) | Feature index per split; `-2` for leaf |
| `splitThresholds` | number array (21) | Threshold per split; `-2.0` for leaf |
| `positiveProbabilities` | number array (21) | Smoothed positive rate per leaf; zero for internal nodes |
| `training` | object | Rows, positives, hyperparameters, CV metrics |

A minimal inference implementation needs only the arrays, the category orders, and the scaler parameters. The `training` object is metadata and is not used at runtime.

---

## Appendix C: Full Decision Tree Rules

The following rules are expressed with raw thresholds where the threshold maps to a meaningful clinical value. Categorical splits are shown as equality or inequality against the encoded category.

```text
Node 0: ST_Slope = Flat?
├── Yes (node 1: Sex = Male?)
│   ├── Yes (node 2: ChestPainType = ASY?)
│   │   ├── Yes (node 3: FastingBS = 1?)
│   │   │   ├── No  -> leaf 4, score 0.9077
│   │   │   └── Yes -> leaf 5, score 0.9670
│   │   └── No (node 6: MaxHR <= 130.5?)
│   │       ├── Yes -> leaf 7, score 0.8627
│   │       └── No  -> leaf 8, score 0.6250
│   └── No (female) -> leaf 9, score 0.5185
└── No (node 10: ChestPainType = ASY?)
    ├── Yes (node 11: ExerciseAngina = Yes?)
    │   ├── Yes -> leaf 12, score 0.8118
    │   └── No (node 13: RestingBP <= 125.5?)
    │       ├── Yes -> leaf 14, score 0.5263
    │       └── No  -> leaf 15, score 0.2407
    └── No (node 16: Age <= 56.5?)
        ├── Yes (node 17: RestingBP <= 119?)
        │   ├── Yes -> leaf 18, score 0.1702
        │   └── No  -> leaf 19, score 0.0333
        └── No -> leaf 20, score 0.2676
```

The exact node arrays are in `heart-disease-model.json`; the text above is a readability aid, not the source of truth.

---

## Appendix D: Database DDL

```sql
CREATE DATABASE IF NOT EXISTS titanic_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE titanic_db;

CREATE TABLE IF NOT EXISTS heart_disease_predictions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    age SMALLINT UNSIGNED NOT NULL,
    sex CHAR(1) NOT NULL,
    chest_pain_type VARCHAR(3) NOT NULL,
    resting_bp SMALLINT UNSIGNED NOT NULL,
    cholesterol SMALLINT UNSIGNED NOT NULL,
    fasting_bs TINYINT UNSIGNED NOT NULL,
    resting_ecg VARCHAR(6) NOT NULL,
    max_hr SMALLINT UNSIGNED NOT NULL,
    exercise_angina CHAR(1) NOT NULL,
    st_slope VARCHAR(5) NOT NULL,
    predicted_heart_disease BOOLEAN NOT NULL,
    model_score DECIMAL(9, 8) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
);
```

The script is idempotent and non-destructive. It does not drop the database or any existing table.

---

## Appendix E: Glossary

| Term | Definition |
|---|---|
| **AUC** | Area under the receiver operating characteristic curve; a discrimination measure. |
| **Brier score** | Mean squared difference between predicted probability and outcome. |
| **CART** | Classification and Regression Trees; a family of decision-tree algorithms. |
| **Calibration** | Agreement between predicted probabilities and observed event rates. |
| **Entropy** | An impurity measure based on the negative log of class probabilities. |
| **Gini impurity** | An impurity measure based on the probability of misclassification. |
| **Leaf smoothing** | Shrinking leaf probabilities toward a prior, often 0.5, to avoid extreme estimates. |
| **Log loss** | Cross-entropy loss; penalises confident wrong probabilistic predictions. |
| **MinMax scaling** | Transforming a feature to a fixed range, usually [0, 1]. |
| **NPV / PPV** | Negative / positive predictive value; the probability that a negative / positive prediction is correct. |
| **Oldpeak** | ST-segment depression induced by exercise relative to rest. |
| **Ordinal encoding** | Mapping ordered or unordered categories to integer codes. |
| **Razor Pages** | A page-focused ASP.NET Core web framework. |
| **Sensitivity / specificity** | True-positive rate / true-negative rate. |
| **ST slope** | The slope of the ST segment during exercise testing: flat, upsloping, or downsloping. |

---

## Appendix F: Model Card

| Field | Content |
|---|---|
| **Model name** | Heartwise / Cardio Signal decision tree |
| **Version** | As embedded in `heart-disease-model.json` (no semantic version field) |
| **Model type** | Shallow CART decision tree with Beta-smoothed leaves |
| **Intended use** | Educational demonstration of model-assisted heart-health screening |
| **Out-of-scope use** | Diagnosis, treatment decisions, triage, insurance, employment, or any clinical decision without clinician oversight |
| **Inputs** | Age, sex, chest-pain type, resting BP, cholesterol, fasting BS, resting ECG, max HR, exercise angina, ST slope |
| **Output** | A score in [0, 1] and a flag at 0.5 |
| **Training data** | 918-row combined UCI heart disease derivative (`heart.csv`) |
| **Training rows / positives** | 918 / 508 |
| **Selected hyperparameters** | Depth 4, min leaf 40, entropy, α = 3 |
| **Tree size** | 21 nodes, 11 leaves |
| **CV metrics** | Accuracy 0.8224; AUC 0.8933; log loss 0.3992; Brier 0.1242 |
| **Calibration** | Reasonable on five out-of-fold bins; no post-hoc calibration |
| **Subgroup performance** | Not reported |
| **External validation** | None |
| **Known limitations** | Retrospective data; single dataset; 79% male; 18.7% missing cholesterol; Oldpeak omitted; cholesterol and resting ECG unused by the fitted tree; no uncertainty quantification |
| **Ethical considerations** | Not a medical device; clinician oversight required; privacy and fairness review needed; diagnostic wording should be revised |
| **Maintenance** | Retrain with `train_heart_model.py`; verify 918/918 round-trip; review metrics before deployment |

---

*End of paper.*
