param(
    [string]$Server = "localhost",
    [uint16]$Port = 3306,
    [string]$Database = "titanic_db"
)

$projectPath = Join-Path $PSScriptRoot "TitanicPredictionWeb.csproj"
if (-not (Test-Path $projectPath)) {
    throw "Could not find the web project at '$projectPath'."
}

# Start the portable local MySQL server when it is installed and not already listening.
$localMySqlRoot = "C:\Users\ayush\mysql"
$localMySql = Join-Path $localMySqlRoot "mysql-8.4.13-winx64\bin\mysqld.exe"
$localMySqlConfig = Join-Path $localMySqlRoot "my.ini"
$mysqlListening = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if (-not $mysqlListening -and (Test-Path $localMySql) -and (Test-Path $localMySqlConfig)) {
    Write-Host "Starting the local MySQL server on port $Port..."
    Start-Process -FilePath $localMySql -ArgumentList "--defaults-file=$localMySqlConfig" -WindowStyle Hidden | Out-Null
    $mysqlStarted = $false
    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        Start-Sleep -Seconds 1
        if (Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue) {
            $mysqlStarted = $true
            break
        }
    }
    if (-not $mysqlStarted) {
        throw "The local MySQL server did not start on port $Port."
    }
    Write-Host "MySQL is ready."
}

$mysqlUsername = "root"
$securePassword = Read-Host "Enter the MySQL password for account '$mysqlUsername' on $Server" -AsSecureString
$passwordPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
$builder = [System.Data.Common.DbConnectionStringBuilder]::new()
$builder["Server"] = $Server
$builder["Port"] = $Port
$builder["Database"] = $Database
$builder["User ID"] = $mysqlUsername
$builder["Password"] = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($passwordPointer)

$env:ConnectionStrings__HeartDiseaseDatabase = $builder.ConnectionString
try {
    Push-Location $PSScriptRoot
    try {
        & dotnet run --project $projectPath --urls "http://127.0.0.1:5188"
        if ($LASTEXITCODE -ne 0) {
            throw "The Heartwise website exited with code $LASTEXITCODE."
        }
    }
    finally {
        Pop-Location
    }
}
finally {
    Remove-Item Env:ConnectionStrings__HeartDiseaseDatabase -ErrorAction SilentlyContinue
    $builder["Password"] = ""
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($passwordPointer)
    $securePassword.Dispose()
}
