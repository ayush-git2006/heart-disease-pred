"""
Retrain the heart-disease decision tree and export the JSON model consumed by
TitanicPredictionWeb/Services/HeartDiseasePredictionService.cs.

Why this script exists
----------------------
The original model was a fully grown DecisionTreeClassifier. Every leaf was
pure (all patients healthy or all patients diseased), so the exported
`positiveProbabilities` could only ever be 0.0 or 1.0. This script trains a
depth-limited, leaf-smoothed tree so the site reports graded risk estimates
instead of only 0% / 100%.

Data
----
heart.csv is the combined UCI Heart Disease dataset (Cleveland, Hungary,
Switzerland, VA Long Beach; 918 rows) already shipped with this project.
Oldpeak is dropped because the web form does not collect it.

Cleaning
--------
* Cholesterol == 0 and RestingBP == 0 are physiologically impossible and are
  treated as missing, then imputed with the training-fold median for that sex.
* Imputation, encoding and scaling are fitted inside each CV fold, so the
  reported metrics do not leak validation data.

Model selection
---------------
5-fold stratified CV over max_depth / min_samples_leaf / criterion, with a
Beta(alpha, alpha) prior applied to each leaf's positive rate. The
(configuration, alpha) pair with the best mean log loss is exported.

Output contract (must match HeartDiseasePredictionService)
----------------------------------------------------------
transformed order:
    ChestPainType, RestingECG, ExerciseAngina, ST_Slope, Sex,
    Age, RestingBP, Cholesterol, FastingBS, MaxHR
scaled[i] = transformed[i] * scalerScales[i] + scalerOffsets[i]
node = scaled[splitFeature] <= splitThreshold ? left : right
score = positiveProbabilities[leaf]
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    brier_score_loss,
    log_loss,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import MinMaxScaler
from sklearn.tree import DecisionTreeClassifier

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "heart.csv"
OUTPUT_PATH = ROOT / "TitanicPredictionWeb" / "Models" / "heart-disease-model.json"

TARGET = "HeartDisease"
CATEGORICAL = ["Sex", "ChestPainType", "RestingECG", "ExerciseAngina", "ST_Slope"]
NUMERIC = ["Age", "RestingBP", "Cholesterol", "FastingBS", "MaxHR"]

# Category order is fixed by the C# service and must not change.
CATEGORY_MAPS = {
    "ChestPainType": ["ASY", "NAP", "ATA", "TA"],
    "RestingECG": ["Normal", "ST", "LVH"],
    "ExerciseAngina": ["Y", "N"],
    "ST_Slope": ["Flat", "Up", "Down"],
    "Sex": ["M", "F"],
}

# The order in which the C# service builds its transformed vector.
TRANSFORMER_ORDER = [
    "ChestPainType",
    "RestingECG",
    "ExerciseAngina",
    "ST_Slope",
    "Sex",
    "Age",
    "RestingBP",
    "Cholesterol",
    "FastingBS",
    "MaxHR",
]

IMPUTED = ["Cholesterol", "RestingBP"]

DEPTHS = [3, 4, 5, 6, 7]
LEAF_SIZES = [20, 30, 40, 50, 60, 80, 100]
CRITERIA = ["gini", "entropy"]
ALPHAS = [0.5, 1.0, 2.0, 3.0, 5.0, 8.0]
SEED = 42


def load_frame() -> pd.DataFrame:
    frame = pd.read_csv(DATA_PATH)
    frame = frame.drop(columns=["Oldpeak"], errors="ignore")
    for column in IMPUTED:
        frame[column] = frame[column].mask(frame[column] <= 0)
    return frame


def impute(frame: pd.DataFrame, medians: pd.DataFrame) -> pd.DataFrame:
    result = frame.copy()
    for column in IMPUTED:
        result[column] = result[column].fillna(result["Sex"].map(medians[column]))
        if result[column].isna().any():
            result[column] = result[column].fillna(medians[column].median())
    return result


def encode(frame: pd.DataFrame) -> pd.DataFrame:
    result = pd.DataFrame(index=frame.index)
    for column, order in CATEGORY_MAPS.items():
        mapping = {value: index for index, value in enumerate(order)}
        result[column] = frame[column].map(mapping)
        if result[column].isna().any():
            unknown = sorted(frame.loc[result[column].isna(), column].unique())
            raise ValueError(f"Unknown categories in {column}: {unknown}")
    for column in NUMERIC:
        result[column] = frame[column].astype(float)
    return result[TRANSFORMER_ORDER]


def fold_matrices(frame: pd.DataFrame) -> list[tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]]:
    """Encode + scale once per fold; the same matrices are reused by every tree."""
    target = frame[TARGET].to_numpy()
    splitter = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
    folds = []
    for train_index, valid_index in splitter.split(frame, target):
        train_frame = frame.iloc[train_index]
        valid_frame = frame.iloc[valid_index]
        medians = train_frame.groupby("Sex")[IMPUTED].median()
        train_encoded = encode(impute(train_frame, medians))
        valid_encoded = encode(impute(valid_frame, medians))
        scaler = MinMaxScaler().fit(train_encoded)
        folds.append(
            (
                scaler.transform(train_encoded),
                scaler.transform(valid_encoded),
                target[train_index],
                target[valid_index],
            )
        )
    return folds


def leaf_probabilities(
    tree: DecisionTreeClassifier, features: np.ndarray, target: np.ndarray, alpha: float
) -> np.ndarray:
    """Beta(alpha, alpha)-smoothed positive rate for every node (leaves are used)."""
    leaves = tree.apply(features)
    node_count = tree.tree_.node_count
    counts = np.bincount(leaves, minlength=node_count).astype(float)
    positives = np.bincount(leaves, weights=target, minlength=node_count)
    probabilities = np.zeros(node_count, dtype=float)
    populated = counts > 0
    probabilities[populated] = (positives[populated] + alpha) / (
        counts[populated] + 2.0 * alpha
    )
    return probabilities


def main() -> None:
    frame = load_frame()
    target = frame[TARGET].to_numpy()
    folds = fold_matrices(frame)

    results = []
    for depth in DEPTHS:
        for leaf_size in LEAF_SIZES:
            for criterion in CRITERIA:
                folds_for_config = []
                for train_x, valid_x, train_y, valid_y in folds:
                    tree = DecisionTreeClassifier(
                        max_depth=depth,
                        min_samples_leaf=leaf_size,
                        criterion=criterion,
                        random_state=SEED,
                    ).fit(train_x, train_y)
                    leaves_train = tree.apply(train_x)
                    node_count = tree.tree_.node_count
                    counts = np.bincount(leaves_train, minlength=node_count).astype(float)
                    positives = np.bincount(
                        leaves_train, weights=train_y, minlength=node_count
                    )
                    folds_for_config.append(
                        (tree, valid_x, valid_y, counts, positives)
                    )

                for alpha in ALPHAS:
                    probabilities = []
                    truths = []
                    for tree, valid_x, valid_y, counts, positives in folds_for_config:
                        node_count = tree.tree_.node_count
                        leaf_rate = np.zeros(node_count, dtype=float)
                        populated = counts > 0
                        leaf_rate[populated] = (positives[populated] + alpha) / (
                            counts[populated] + 2.0 * alpha
                        )
                        probabilities.append(leaf_rate[tree.apply(valid_x)])
                        truths.append(valid_y)

                    probability = np.concatenate(probabilities)
                    truth = np.concatenate(truths)
                    results.append(
                        {
                            "max_depth": depth,
                            "min_samples_leaf": leaf_size,
                            "criterion": criterion,
                            "alpha": alpha,
                            "nodes": folds_for_config[0][0].tree_.node_count,
                            "leaves": int(folds_for_config[0][0].get_n_leaves()),
                            "log_loss": log_loss(truth, probability),
                            "roc_auc": roc_auc_score(truth, probability),
                            "accuracy": accuracy_score(
                                truth, (probability >= 0.5).astype(int)
                            ),
                            "brier": brier_score_loss(truth, probability),
                            "proba": probability,
                            "truth": truth,
                        }
                    )

    results.sort(key=lambda row: (row["log_loss"], -row["roc_auc"]))
    best = results[0]

    print("Dataset")
    print(f"  rows: {len(frame)}  positives: {int(target.sum())}  negatives: {int((1 - target).sum())}")
    print(f"  cholesterol treated as missing: {int(frame['Cholesterol'].isna().sum())}")
    print(f"  resting BP treated as missing:  {int(frame['RestingBP'].isna().sum())}")
    print()

    print("Top 5 configurations (5-fold CV, log-loss order)")
    print(
        f"  {'depth':>5} {'leaf':>5} {'criterion':>9} {'alpha':>6} "
        f"{'logloss':>8} {'auc':>7} {'acc':>7} {'brier':>7} {'nodes':>6} {'leaves':>6}"
    )
    for row in results[:5]:
        print(
            f"  {row['max_depth']:>5} {row['min_samples_leaf']:>5} {row['criterion']:>9} "
            f"{row['alpha']:>6.1f} {row['log_loss']:>8.4f} {row['roc_auc']:>7.4f} "
            f"{row['accuracy']:>7.4f} {row['brier']:>7.4f} {row['nodes']:>6} {row['leaves']:>6}"
        )
    print()

    # Fit the selected configuration on all rows.
    medians = frame.groupby("Sex")[IMPUTED].median()
    encoded = encode(impute(frame, medians))
    scaler = MinMaxScaler().fit(encoded)
    features = scaler.transform(encoded)
    tree = DecisionTreeClassifier(
        max_depth=best["max_depth"],
        min_samples_leaf=best["min_samples_leaf"],
        criterion=best["criterion"],
        random_state=SEED,
    ).fit(features, target)

    alpha = best["alpha"]
    leaf_rate = leaf_probabilities(tree, features, target, alpha)
    node_count = tree.tree_.node_count
    exported_probabilities = np.zeros(node_count, dtype=float)
    is_leaf = tree.tree_.children_left == -1
    exported_probabilities[is_leaf] = leaf_rate[is_leaf]

    tree_data = tree.tree_
    model = {
        "sourceModel": "heart.csv (combined UCI heart disease), retrained with a smoothed shallow tree",
        "inputFeatures": [
            "Age",
            "Sex",
            "ChestPainType",
            "RestingBP",
            "Cholesterol",
            "FastingBS",
            "RestingECG",
            "MaxHR",
            "ExerciseAngina",
            "ST_Slope",
        ],
        "encodedCategories": {column: list(order) for column, order in CATEGORY_MAPS.items()},
        "transformerOutputFeatures": TRANSFORMER_ORDER,
        "scalerScales": [float(value) for value in scaler.scale_],
        "scalerOffsets": [float(value) for value in scaler.min_],
        "selectedFeatures": [True] * len(TRANSFORMER_ORDER),
        "childrenLeft": [int(value) for value in tree_data.children_left],
        "childrenRight": [int(value) for value in tree_data.children_right],
        "splitFeatures": [int(value) for value in tree_data.feature],
        "splitThresholds": [float(value) for value in tree_data.threshold],
        "positiveProbabilities": [float(value) for value in exported_probabilities],
        "training": {
            "rows": int(len(frame)),
            "positives": int(target.sum()),
            "maxDepth": int(best["max_depth"]),
            "minSamplesLeaf": int(best["min_samples_leaf"]),
            "criterion": best["criterion"],
            "leafAlpha": float(best["alpha"]),
            "crossValidation": {
                "folds": 5,
                "logLoss": round(float(best["log_loss"]), 6),
                "rocAuc": round(float(best["roc_auc"]), 6),
                "accuracy": round(float(best["accuracy"]), 6),
                "brier": round(float(best["brier"]), 6),
            },
        },
    }

    OUTPUT_PATH.write_text(
        json.dumps(model, separators=(",", ":"), ensure_ascii=False), encoding="utf-8"
    )

    print("Selected model")
    print(f"  max_depth={best['max_depth']} min_samples_leaf={best['min_samples_leaf']} "
          f"criterion={best['criterion']} alpha={best['alpha']}")
    print(f"  nodes={node_count} leaves={int(tree.get_n_leaves())}")
    print(f"  CV logloss={best['log_loss']:.4f} auc={best['roc_auc']:.4f} "
          f"accuracy={best['accuracy']:.4f} brier={best['brier']:.4f}")
    print(f"  wrote {OUTPUT_PATH}")
    print()

    leaf_values = exported_probabilities[is_leaf]
    unique_values = np.unique(np.round(leaf_values, 6))
    print(f"Leaf probability values ({len(unique_values)} distinct):")
    print("  " + ", ".join(f"{value:.3f}" for value in unique_values))
    print()

    # Reliability table from out-of-fold predictions of the winning configuration.
    probability = best["proba"]
    truth = best["truth"]
    edges = np.linspace(0.0, 1.0, 6)
    print("Out-of-fold calibration (5 bins)")
    print(f"  {'bin':>12} {'n':>5} {'predicted':>10} {'observed':>9}")
    for low, high in zip(edges[:-1], edges[1:]):
        mask = (probability >= low) & (
            probability < high if high < 1.0 else probability <= high
        )
        if mask.sum() == 0:
            continue
        print(
            f"  {low:>5.1f}-{high:<6.1f} {int(mask.sum()):>5} "
            f"{probability[mask].mean():>10.3f} {truth[mask].mean():>9.3f}"
        )
    print()

    # Verify the exported JSON reproduces sklearn's decision function exactly.
    with OUTPUT_PATH.open(encoding="utf-8") as handle:
        exported = json.load(handle)

    def json_predict(values: dict[str, float | int | str]) -> float:
        transformed = [
            float(CATEGORY_MAPS[column].index(values[column]))
            if column in CATEGORY_MAPS
            else float(values[column])
            for column in TRANSFORMER_ORDER
        ]
        scaled = [
            transformed[index] * exported["scalerScales"][index]
            + exported["scalerOffsets"][index]
            for index in range(len(transformed))
        ]
        node = 0
        while exported["splitFeatures"][node] >= 0:
            feature = exported["splitFeatures"][node]
            node = (
                exported["childrenLeft"][node]
                if scaled[feature] <= exported["splitThresholds"][node]
                else exported["childrenRight"][node]
            )
        return exported["positiveProbabilities"][node]

    mismatches = 0
    for row_index in range(len(frame)):
        source = frame.iloc[row_index]
        values = {column: source[column] for column in frame.columns if column != TARGET}
        for column in IMPUTED:
            if pd.isna(values[column]):
                values[column] = medians[column][source["Sex"]]
        expected = leaf_rate[tree.apply(features[row_index : row_index + 1])][0]
        actual = json_predict(values)
        if abs(expected - actual) > 1e-12:
            mismatches += 1
    print(f"JSON round-trip check: {len(frame) - mismatches}/{len(frame)} rows match sklearn")
    print()

    profiles = {
        "form defaults": dict(Age=45, Sex="M", ChestPainType="ATA", RestingBP=120,
                              Cholesterol=200, FastingBS=0, RestingECG="Normal",
                              MaxHR=150, ExerciseAngina="N", ST_Slope="Up"),
        "saved row 5": dict(Age=45, Sex="M", ChestPainType="NAP", RestingBP=120,
                            Cholesterol=200, FastingBS=1, RestingECG="ST",
                            MaxHR=150, ExerciseAngina="Y", ST_Slope="Flat"),
        "saved row 6": dict(Age=47, Sex="M", ChestPainType="NAP", RestingBP=123,
                            Cholesterol=200, FastingBS=1, RestingECG="ST",
                            MaxHR=150, ExerciseAngina="Y", ST_Slope="Flat"),
        "high risk ASY": dict(Age=58, Sex="M", ChestPainType="ASY", RestingBP=128,
                              Cholesterol=259, FastingBS=0, RestingECG="LVH",
                              MaxHR=130, ExerciseAngina="Y", ST_Slope="Flat"),
        "low risk": dict(Age=35, Sex="F", ChestPainType="NAP", RestingBP=110,
                         Cholesterol=180, FastingBS=0, RestingECG="Normal",
                         MaxHR=170, ExerciseAngina="N", ST_Slope="Up"),
    }
    print("Example predictions")
    for name, values in profiles.items():
        print(f"  {name:<16} -> {json_predict(values) * 100:5.1f}%")


if __name__ == "__main__":
    main()
